#include <array>
#include <chrono>
#include <cstdio>
// Copyright 2019 Google LLC & Bastiaan Konings
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// written by bastiaan konings schuiling 2008 - 2014
// this work is public domain. the code is undocumented, scruffy, untested, and should generally not be used for anything important.
// i do not offer support, so don't ask. to be used for inspiration :)

#include "opengl_renderer3d.hpp"
// 2026-09-13: service UI only on the current render owner between batches.
#include "../render_service.hpp"

#ifndef GL_GLEXT_PROTOTYPES
#define GL_GLEXT_PROTOTYPES
#endif
#ifdef __APPLE__
#define GL_SILENCE_DEPRECATION
#include <OpenGL/gl3.h>
#include <OpenGL/gl3ext.h>
#else
#include <GL/gl.h>
#endif

#ifdef __linux__
#include <GL/glext.h>
#define EGL_EGLEXT_PROTOTYPES
#include <EGL/egl.h>
#include <EGL/eglext.h>
#elif defined(WIN32)
#include <SDL2/SDL_opengl_glext.h>
#endif

#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <mutex>
#include <stdexcept>
#include "wrap_SDL.h"

#include "../../../base/geometry/aabb.hpp"
#include "../../../base/geometry/trianglemeshutils.hpp"
#include "../../../base/log.hpp"
#include "../../../base/math/bluntmath.hpp"
#include "../../../base/sdl_surface.hpp"
#include "../../../base/utils.hpp"
#include "../../../main.hpp"
#include "../../../types/command.hpp"
#include "../../../utils/gui2/widgets/image.hpp"
#include "../resources/texture.hpp"

namespace blunted {

struct GLfunctions {
#define SDL_PROC(ret,func,params) ret (APIENTRYP func) params;
#include "sdl_glfuncs.h"
#undef SDL_PROC
};

// 2026-09-09: GL dispatch belongs to the calling thread and selected context.
// GLfunctions mapping;
thread_local GLfunctions mapping{};
#ifdef __linux__
namespace {
std::mutex egl_lifecycle_mutex;
std::map<EGLDisplay, size_t> egl_display_users;
}
#endif

OpenGLRenderer3D::OpenGLRenderer3D() : functions_(std::make_unique<GLfunctions>()) {
  DO_VALIDATION;
  FOV = 45;
  overallBrightness = 128;
  const char *bloom = std::getenv("GFOOTBALL_PBR_BLOOM");
  const char *fxaa = std::getenv("GFOOTBALL_PBR_FXAA");
  const char *autoExposure = std::getenv("GFOOTBALL_PBR_AUTO_EXPOSURE");
  pbrBloomEnabled_ = bloom && bloom[0] == '1' && bloom[1] == '\0';
  pbrFXAAEnabled_ = fxaa && fxaa[0] == '1' && fxaa[1] == '\0';
  pbrAutoExposureEnabled_ = autoExposure && autoExposure[0] == '1' &&
                            autoExposure[1] == '\0';
  if (const char *setting = std::getenv("GFOOTBALL_PBR_EXPOSURE")) {
    char *end = nullptr;
    const float value = std::strtof(setting, &end);
    if (end != setting && *end == '\0' && std::isfinite(value) &&
        value >= 0.1f && value <= 8.0f)
      pbrExposure_ = value;
  }

  _cache_activeTextureUnit = -1;

  currentShader = shaders.end();

  // SetPriorityClass(thread.native_handle(), HIGH_PRIORITY_CLASS);
};

// 2026-09-09: destroying the owned GL context releases its remaining GL objects.
// OpenGLRenderer3D::~OpenGLRenderer3D() { DO_VALIDATION; };
OpenGLRenderer3D::~OpenGLRenderer3D() {
  DO_VALIDATION;
  if (iblTextures_[0] || iblTextures_[1] ||
      iblTextures_[2] || iblTextures_[3]) {
    // GameEnv normally deletes the renderer without calling Exit().
    // Release owned textures while its GL context is still available.
    SetContext();
    DestroyIBLResources();
  }
  if (context) {
    SDL_GL_MakeCurrent(window, nullptr);
    SDL_GL_DeleteContext(context);
    context = nullptr;
  }
  if (window) {
    SDL_DestroyWindow(window);
    window = nullptr;
  }
  if (video_initialized_) SDL_QuitSubSystem(SDL_INIT_VIDEO);
#ifdef __linux__
  if (egl_display != EGL_NO_DISPLAY) {
    std::lock_guard lock(egl_lifecycle_mutex);
    eglMakeCurrent(egl_display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    if (egl_context != EGL_NO_CONTEXT) eglDestroyContext(egl_display, egl_context);
    if (egl_surface != EGL_NO_SURFACE) eglDestroySurface(egl_display, egl_surface);
    auto found = egl_display_users.find(egl_display);
    if (found != egl_display_users.end() && --found->second == 0) {
      eglTerminate(egl_display);
      egl_display_users.erase(found);
    }
    egl_display = EGL_NO_DISPLAY;
  }
#endif
}

void OpenGLRenderer3D::SwapBuffers() {
  // 2026-09-13: preserve GL state while servicing external UI input.
  ScopedRenderService::Poll();
  DO_VALIDATION;
  // 2026-09-13: avoid unused synchronous RGB transfer in native display clients.
  //   last_screen_.resize(context_width * context_height * 3);
  //   // 2026-09-10: read the completed back buffer before presenting it. Reading
  //   // after the swap captured the previous frame and broke correction/HUD pixels.
  //   // if (window) {
  //   //   SDL_GL_SwapWindow(window);
  //   // }
  //   // 2026-09-09: odd RGB widths otherwise add driver row padding past the string allocation.
  //   // mapping.glReadPixels(0, 0, context_width, context_height, GL_RGB, GL_UNSIGNED_BYTE,
  //   //                      &last_screen_[0]);
  //   GLint previous_alignment = 4;
  //   mapping.glGetIntegerv(GL_PACK_ALIGNMENT, &previous_alignment);
  //   mapping.glPixelStorei(GL_PACK_ALIGNMENT, 1);
  //   mapping.glReadPixels(0, 0, context_width, context_height, GL_RGB, GL_UNSIGNED_BYTE,
  //                        last_screen_.data());
  //   mapping.glPixelStorei(GL_PACK_ALIGNMENT, previous_alignment);
  if (GetGameConfig().capture_frames) {
    last_screen_.resize(context_width * context_height * 3);
    // Read the completed back buffer before presentation; preserve caller packing.
    GLint previous_alignment = 4;
    mapping.glGetIntegerv(GL_PACK_ALIGNMENT, &previous_alignment);
    mapping.glPixelStorei(GL_PACK_ALIGNMENT, 1);
    mapping.glReadPixels(0, 0, context_width, context_height, GL_RGB,
                         GL_UNSIGNED_BYTE, last_screen_.data());
    mapping.glPixelStorei(GL_PACK_ALIGNMENT, previous_alignment);
  } else {
    // A frame rendered without capture must never expose earlier RGB pixels.
    last_screen_.clear();
  }
  // 2026-09-13: sample again after a potentially blocking readback.
  ScopedRenderService::Poll();
  if (window) SDL_GL_SwapWindow(window);
}

void OpenGLRenderer3D::SetMatrix(const std::string &shaderUniformName,
                                 const Matrix4 &matrix) {
  DO_VALIDATION;
  SetUniformMatrix4(currentShader->first, shaderUniformName, matrix);
}

// void OpenGLRenderer3D::RenderOverlay2D(MessageQueue<Overlay2DQueueEntry>
// &overlay2DQueue) { DO_VALIDATION;
void OpenGLRenderer3D::RenderOverlay2D(
    const std::vector<Overlay2DQueueEntry> &overlay2DQueue) {
  DO_VALIDATION;

  if (overlay2DQueue.empty()) {
    return;
  }

  mapping.glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  mapping.glEnable(GL_BLEND);
  mapping.glDisable(GL_DEPTH_TEST);
  SetDepthMask(false);
  mapping.glDisable(GL_CULL_FACE);

  UseShader("overlay");

  Matrix4 orthoMatrix = CreateOrthoMatrix(0, context_width, context_height, 0, 0.1, 10);
  SetMatrix("projection", orthoMatrix);

  mapping.glBindVertexArray(overlayBuffer.vertexArrayID);
  SetTextureUnit(0);

  for (unsigned int i = 0; i < overlay2DQueue.size(); i++) {
    DO_VALIDATION;
    const Overlay2DQueueEntry &queueEntry = overlay2DQueue[i];

    Matrix4 modelMatrix(MATRIX4_IDENTITY);
    modelMatrix.SetTranslation(Vector3(queueEntry.position[0], queueEntry.position[1], -1.0f));
    modelMatrix.SetScale(Vector3(queueEntry.size[0], queueEntry.size[1], 1.0f));
    SetMatrix("model", modelMatrix);

    BindTexture(queueEntry.texture->GetResource()->GetID());
    mapping.glDrawArrays(GL_TRIANGLES, 0, 6);
  }

  mapping.glBindVertexArray(0);

  mapping.glEnable(GL_DEPTH_TEST);
  mapping.glEnable(GL_CULL_FACE);
  SetDepthMask(true);
  mapping.glDisable(GL_BLEND);
}

void OpenGLRenderer3D::RenderOverlay2D() {
  // 2026-09-13: preserve GL state while servicing external UI input.
  ScopedRenderService::Poll();
  DO_VALIDATION;

  Matrix4 orthoMatrix = CreateOrthoMatrix(-1, 1, -1, 1, 0.0f, 1.0f);
  SetMatrix("orthoProjectionMatrix", orthoMatrix);
  Matrix4 viewMatrix(MATRIX4_IDENTITY);
  viewMatrix.SetTranslation(Vector3(0, 0, -0.5f));
  SetMatrix("orthoViewMatrix", viewMatrix);

  SetCullingMode(e_CullingMode_Off);

  SetTextureUnit(4);  // noise
  BindTexture(noiseTexID);
  SetTextureUnit(0);

  mapping.glBindVertexArray(quadBuffer.vertexArrayID);
  mapping.glDrawArrays(GL_TRIANGLES, 0, 6);
  mapping.glBindVertexArray(0);

  // unbind noise
  SetTextureUnit(4);
  BindTexture(0);

  SetCullingMode(e_CullingMode_Back);
}

void drawSphere(float r, int lats, int longs) {
  DO_VALIDATION;
  // Never called (because light.type is always set to 0) and uses deprecated methods.
  // Possible implementation, that uses modern OpenGl can be found here:
  // https://gist.github.com/zwzmzd/0195733fa1210346b00d
  /*
  int i, j;
  for (i = 0; i <= lats; i++) {
    DO_VALIDATION;
    float lat0 = pi * (-0.5 + (float)(i - 1) / lats);
    float z0 = std::sin(lat0);
    float zr0 = std::cos(lat0);

    float lat1 = pi * (-0.5 + (float)i / lats);
    float z1 = std::sin(lat1);
    float zr1 = std::cos(lat1);

    mapping.glBegin(GL_QUAD_STRIP);
    for (j = 0; j <= longs; j++) {
      DO_VALIDATION;
      float lng = 2 * pi * (float)(j - 1) / longs;
      float x = std::cos(lng);
      float y = std::sin(lng);

      mapping.glNormal3f(x * zr0, y * zr0, z0);
      mapping.glVertex3f(x * zr0 * r, y * zr0 * r, z0 * r);
      mapping.glNormal3f(x * zr1, y * zr1, z1);
      mapping.glVertex3f(x * zr1 * r, y * zr1 * r, z1 * r);
    }
    mapping.glEnd();
  }
   */
}

void OpenGLRenderer3D::RenderLights(std::deque<LightQueueEntry> &lightQueue,
                                    const Matrix4 &projectionMatrix,
                                    const Matrix4 &viewMatrix) {
  DO_VALIDATION;
  Vector3 cameraPos = viewMatrix.GetInverse().GetTranslation();

  //  mapping.glDisable(GL_ALPHA_TEST);

  SetUniformFloat3(currentShader->first, "cameraPosition", cameraPos.coords[0],
                   cameraPos.coords[1], cameraPos.coords[2]);

  std::deque<LightQueueEntry>::iterator lightIter = lightQueue.begin();

  while (lightIter != lightQueue.end()) {
    // 2026-09-13: bounded opportunity between complete draw batches.
    ScopedRenderService::Poll();
    DO_VALIDATION;
    const LightQueueEntry &light = (*lightIter);

    // bind shadow map
    SetUniformInt(currentShader->first, "has_shadow", (int)light.hasShadow);
    if (light.hasShadow) {
      DO_VALIDATION;
      SetTextureUnit(7);
      //mapping.glEnable(GL_TEXTURE_2D);
      mapping.glBindTexture(GL_TEXTURE_2D,
                            light.shadowMapTexture->GetResource()->GetID());

      Matrix4 toTexCoords(MATRIX4_IDENTITY);
      toTexCoords.SetTranslation(Vector3(0.5f, 0.5f, 0.5f));
      toTexCoords.SetScale(Vector3(0.5f, 0.5f, 0.5f));
      SetUniformMatrix4(currentShader->first, "lightViewProjectionMatrix",
                        toTexCoords * (*lightIter).lightProjectionMatrix *
                            (*lightIter).lightViewMatrix);

    } else {
      //mapping.glDisable(GL_TEXTURE_2D);
    }

    SetUniformFloat3(currentShader->first, "lightColor", light.color.coords[0],
                     light.color.coords[1], light.color.coords[2]);
    SetUniformFloat(currentShader->first, "lightRadius", light.radius);
    SetUniformFloat3(currentShader->first, "lightPosition",
                     light.position.coords[0], light.position.coords[1],
                     light.position.coords[2]);

    int quad_or_sphere = 1;
    if (light.type == 0) {
      DO_VALIDATION;

      quad_or_sphere = 0;  // directional light: visible anyway, everywhere.
                           // draw fullscreen quad

    } else if (light.type == 1) {
      DO_VALIDATION;  // sphere
      AABB aabb = light.aabb;
      // get the spherical bounding box of the aabb
      // if the camera is inside this sphere, draw a fullscreen quad instead of
      // a sphere else, the sphere wouldn't be rendered..
      // float boundingSphereRadius =
      // aabb.GetRadius();//light.position.GetDistance(Vector3(aabb.minxyz.coords[0],
      // aabb.minxyz.coords[1], aabb.minxyz.coords[2]));
      if (cameraPos.GetDistance(light.position) <= aabb.GetRadius()) {
        DO_VALIDATION;
        // cam is within light radius, draw all
        quad_or_sphere = 0;
      } else {
        quad_or_sphere = 1;
      }
    }

    if (quad_or_sphere == 0) {
      DO_VALIDATION;

      // QUAD

      SetCullingMode(e_CullingMode_Off);
      SetDepthFunction(e_DepthFunction_Always);

      Matrix4 orthoMatrix = CreateOrthoMatrix(-1, 1, -1, 1, 0.0f, 1.0f);
      SetMatrix("projectionMatrix", orthoMatrix);
      Matrix4 xviewMatrix(MATRIX4_IDENTITY);
      xviewMatrix.SetTranslation(Vector3(0, 0, -0.5f));
      SetMatrix("viewMatrix", xviewMatrix);
      Matrix4 modelMatrix(MATRIX4_IDENTITY);
      SetMatrix("modelMatrix", modelMatrix);

      mapping.glBindVertexArray(quadBuffer.vertexArrayID);
      mapping.glDrawArrays(GL_TRIANGLES, 0, 6);
      mapping.glBindVertexArray(0);
    } else {  // Never called (because light.type is always set to 0)
      // SPHERE

      SetCullingMode(e_CullingMode_Back);
      SetDepthFunction(e_DepthFunction_Less);

      AABB aabb = light.aabb;

      SetMatrix("projectionMatrix", projectionMatrix);
      SetMatrix("viewMatrix", viewMatrix);
      Matrix4 modelMatrix(MATRIX4_IDENTITY);
      modelMatrix.SetTranslation(light.position);
      SetMatrix("modelMatrix", modelMatrix);
      drawSphere(aabb.GetRadius() * 0.52f, 6, 6);
    }

    if (light.hasShadow) {
      DO_VALIDATION;
      mapping.glBindTexture(GL_TEXTURE_2D, 0);
      //mapping.glDisable(GL_TEXTURE_2D);
      SetTextureUnit(0);
    }

    lightIter++;
  }
}

  // --- new & improved


  // init & exit

VertexBufferID OpenGLRenderer3D::CreateSimpleVertexBuffer(GLfloat *vertices, unsigned int size) {
  GLuint VBO, VAO;
  mapping.glGenVertexArrays(1, &VAO);
  mapping.glGenBuffers(1, &VBO);

  mapping.glBindVertexArray(VAO);

  mapping.glBindBuffer(GL_ARRAY_BUFFER, VBO);
  mapping.glBufferData(GL_ARRAY_BUFFER, size, vertices, GL_STATIC_DRAW);

  mapping.glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 4 * sizeof(GLfloat), (GLvoid*)0);
  mapping.glEnableVertexAttribArray(0);

  mapping.glBindBuffer(GL_ARRAY_BUFFER, 0);
  mapping.glBindVertexArray(0);

  VertexBufferID vertexBufferId;
  vertexBufferId.bufferID = VBO;
  vertexBufferId.vertexArrayID = VAO;
  return vertexBufferId;
}

void OpenGLRenderer3D::DeleteSimpleVertexBuffer(VertexBufferID vertexBufferID) {
  DO_VALIDATION;
  GLuint glVertexBufferID = vertexBufferID.bufferID;
  mapping.glDeleteBuffers(1, &glVertexBufferID);

  GLuint glVertexArrayID = vertexBufferID.vertexArrayID;
  mapping.glDeleteVertexArrays(1, &glVertexArrayID);
}

// This method was introduced to replace OpenGL's fixed function pipeline
// (e.g. glBegin, glEnd, etc.) that was used for overlay rendering.
void OpenGLRenderer3D::InitializeOverlayAndQuadBuffers() {
  GLfloat overlayVertices[] = {
          0.0f, 1.0f, 0.0f, 1.0f,
          1.0f, 0.0f, 0.0f, 1.0f,
          0.0f, 0.0f, 0.0f, 1.0f,

          0.0f, 1.0f, 0.0f, 1.0f,
          1.0f, 1.0f, 0.0f, 1.0f,
          1.0f, 0.0f, 0.0f, 1.0f
  };
  overlayBuffer = CreateSimpleVertexBuffer(overlayVertices, sizeof(overlayVertices));

  GLfloat quadVertices[] = {
          -1.0f,  1.0f, 0.0f, 1.0f,
          1.0f, -1.0f, 0.0f, 1.0f,
          -1.0f, -1.0f, 0.0f, 1.0f,

          -1.0f,  1.0f, 0.0f, 1.0f,
          1.0f,  1.0f, 0.0f, 1.0f,
          1.0f, -1.0f, 0.0f, 1.0f
  };
  quadBuffer = CreateSimpleVertexBuffer(quadVertices, sizeof(quadVertices));
}

// 2026-09-09: context failures propagate to GameEnv cleanup and retry; never terminate the host.
// void OpenGLRenderer3D::CreateContextSdl() {
//   DO_VALIDATION;
//   // 2026-09-09: balance only this renderer's video subsystem reference.
//   // SDL_Init(SDL_INIT_VIDEO);
//   if (SDL_InitSubSystem(SDL_INIT_VIDEO) != 0) throw std::runtime_error(SDL_GetError());
//   video_initialized_ = true;
//
//   SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 8);
//   SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 8);
//   SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 8);
//   SDL_GL_SetAttribute(SDL_GL_ALPHA_SIZE, 8);
//   SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 16);
//
//   SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
//
//   SDL_GL_SetAttribute(SDL_GL_ACCELERATED_VISUAL, 1);  // DISABLED?
//
// #ifdef __APPLE__
//   SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
//   SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 2);
//   SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
// #endif
//
//   window = SDL_CreateWindow("Google Research Football", SDL_WINDOWPOS_UNDEFINED,
//                             SDL_WINDOWPOS_UNDEFINED, context_width,
//                             context_height, SDL_WINDOW_OPENGL);
//   context = SDL_GL_CreateContext(window);
//
//   if (!context) {
//     DO_VALIDATION;
//     std::string errorString = SDL_GetError();
//     std::cout << "Failed on SDL error: " << errorString << std::endl;
//     std::cout << "You can solve this problem by:" << std::endl;
//     std::cout << "1) If you are running inside Docker make sure container has "
//                  "access to XServer by running (outside of the container):"
//               << std::endl;
//     std::cout << "  > xhost +\"local:docker@\"" << std::endl;
//     std::cout << "2) Switch to off-screen rendering by unsetting DISPLAY "
//                  "environment variable"
//               << std::endl;
//     std::cout
//         << "3) Disable 3D rendering (which makes environment run much faster)."
//         << std::endl;
//     exit(1);
//   }
// #define SDL_PROC(ret, func, params)                                        \
//   do {                                                                     \
//     *reinterpret_cast<void **>(&(mapping.func)) =                          \
//         SDL_GL_GetProcAddress(#func);                                      \
//     if (!mapping.func) {                                                   \
//       DO_VALIDATION;                                                       \
//       printf("Couldn't load GL function %s: %s\n", #func, SDL_GetError()); \
//       SDL_SetError("Couldn't load GL function %s: %s\n", #func,            \
//                    SDL_GetError());                                        \
//       print_stacktrace();                                                  \
//       exit(1);                                                             \
//     }                                                                      \
//   } while (0);
// #include "sdl_glfuncs.h"
// #undef SDL_PROC
//   *functions_ = mapping;
// }
//
// #ifdef __linux__
// // Helper macro to check for EGL errors.
// #define FAIL_IF_EGL_ERROR(egl_expr)                             \
//   do {                                                          \
//     (egl_expr);                                                 \
//     auto error = eglGetError();                                 \
//     if (error != EGL_SUCCESS) {                                 \
//       Log(e_FatalError, "OpenGLRenderer3D", "CreateContextEgl", \
//           "EGL failure: " + int_to_str(__LINE__));              \
//     }                                                           \
//   } while (false)
//
// void OpenGLRenderer3D::CreateContextEgl() {
//   std::lock_guard lock(egl_lifecycle_mutex);
//   static const int MAX_DEVICES = 16;
//   EGLDeviceEXT eglDevs[MAX_DEVICES];
//   EGLint numDevices;
//   PFNEGLQUERYDEVICESEXTPROC eglQueryDevicesEXT =
//       (PFNEGLQUERYDEVICESEXTPROC)eglGetProcAddress("eglQueryDevicesEXT");
//   if (eglQueryDevicesEXT == nullptr) {
//     Log(e_FatalError, "OpenGLRenderer3D", "CreateContextEgl",
//         "Failed on obtain eglQueryDevicesEXT function");
//   }
//   eglQueryDevicesEXT(MAX_DEVICES, eglDevs, &numDevices);
//
//   PFNEGLGETPLATFORMDISPLAYEXTPROC eglGetPlatformDisplayEXT =
//       (PFNEGLGETPLATFORMDISPLAYEXTPROC)eglGetProcAddress(
//           "eglGetPlatformDisplayEXT");
//   if (eglGetPlatformDisplayEXT == nullptr) {
//     Log(e_FatalError, "OpenGLRenderer3D", "CreateContextEgl",
//         "Failed on obtain eglGetPlatformDisplayEXT function");
//   }
//   EGLBoolean success;
//   int major, minor;
//   for (EGLint i = 0; i < numDevices; ++i) {
//     EGLDisplay display =
//         eglGetPlatformDisplayEXT(EGL_PLATFORM_DEVICE_EXT, eglDevs[i], nullptr);
//     if (eglGetError() == EGL_SUCCESS && display != EGL_NO_DISPLAY) {
//       // 2026-09-09: an existing display may serve another live environment.
//       if (egl_display_users.contains(display)) {
//         ++egl_display_users[display];
//         egl_display = display;
//         break;
//       }
//       success = eglInitialize(display, &major, &minor);
//       if (eglGetError() == EGL_SUCCESS && success == EGL_TRUE) {
//         egl_display = display;
//         egl_display_users[display] = 1;
//         break;
//       }
//     }
//   }
//   if (egl_display == EGL_NO_DISPLAY) {
//     Log(e_FatalError, "OpenGLRenderer3D", "CreateContextEgl",
//         "Failed on construct EGL Display");
//   }
//
//   FAIL_IF_EGL_ERROR(success = eglBindAPI(EGL_OPENGL_API));
//   EGLint num_configs;
//   EGLConfig egl_config;
//   constexpr EGLint kConfigAttribs[] = {EGL_RED_SIZE,
//                                        8,
//                                        EGL_GREEN_SIZE,
//                                        8,
//                                        EGL_BLUE_SIZE,
//                                        8,
//                                        EGL_SURFACE_TYPE,
//                                        EGL_PBUFFER_BIT,
//                                        EGL_RENDERABLE_TYPE,
//                                        EGL_OPENGL_BIT,
//                                        EGL_NONE};
//   FAIL_IF_EGL_ERROR(success = eglChooseConfig(egl_display, kConfigAttribs,
//                                               &egl_config, 1, &num_configs));
//
//   // Create EGL surface.
//   EGLint kPixelBufferAttribs[] = {
//       EGL_WIDTH, context_width, EGL_HEIGHT, context_height, EGL_NONE,
//   };
//   FAIL_IF_EGL_ERROR(egl_surface = eglCreatePbufferSurface(
//                         egl_display, egl_config, kPixelBufferAttribs));
//
//   FAIL_IF_EGL_ERROR(egl_context = eglCreateContext(egl_display, egl_config,
//                                                    EGL_NO_CONTEXT, nullptr));
//   FAIL_IF_EGL_ERROR(
//       eglMakeCurrent(egl_display, egl_surface, egl_surface, egl_context));
// #define SDL_PROC(ret, func, params)                                        \
//   do {                                                                     \
//     *reinterpret_cast<void **>(&(mapping.func)) =                          \
//         (void*) eglGetProcAddress(#func);                                          \
//     if (!mapping.func) {                                                   \
//       DO_VALIDATION;                                                       \
//       printf("Couldn't load mapping.gl function %s\n", #func); \
//       SDL_SetError("Couldn't load mapping.gl function %s\n", #func);               \
//       print_stacktrace();                                                  \
//       exit(1);                                                             \
//     }                                                                      \
//   } while (0);
// #include "sdl_glfuncs.h"
// #undef SDL_PROC
//   *functions_ = mapping;
// }
// #endif
//
void OpenGLRenderer3D::CreateContextSdl() {
  if (SDL_InitSubSystem(SDL_INIT_VIDEO) != 0)
    throw std::runtime_error(std::string("SDL video initialization: ") + SDL_GetError());
  video_initialized_ = true;
  SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 8);
  SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 8);
  SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 8);
  SDL_GL_SetAttribute(SDL_GL_ALPHA_SIZE, 8);
  SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 16);
  SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
#ifdef __APPLE__
  SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
  SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 2);
  SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
#endif
  window = SDL_CreateWindow("Football", SDL_WINDOWPOS_UNDEFINED,
                            SDL_WINDOWPOS_UNDEFINED, context_width,
                            context_height, SDL_WINDOW_OPENGL);
  if (!window) throw std::runtime_error(std::string("SDL window creation: ") + SDL_GetError());
  context = SDL_GL_CreateContext(window);
  if (!context) throw std::runtime_error(std::string("SDL GL context creation: ") + SDL_GetError());
#define SDL_PROC(ret, func, params)                                       \
  do {                                                                    \
    mapping.func = reinterpret_cast<decltype(mapping.func)>(SDL_GL_GetProcAddress(#func)); \
    if (!mapping.func) throw std::runtime_error("Missing SDL GL function: " #func); \
  } while (false);
#include "sdl_glfuncs.h"
#undef SDL_PROC
  *functions_ = mapping;
}

#ifdef __linux__
void OpenGLRenderer3D::CreateContextEgl() {
  std::lock_guard lock(egl_lifecycle_mutex);
  constexpr int max_devices = 16;
  EGLDeviceEXT devices[max_devices]{};
  EGLint device_count = 0;
  auto query_devices = reinterpret_cast<PFNEGLQUERYDEVICESEXTPROC>(
      eglGetProcAddress("eglQueryDevicesEXT"));
  auto platform_display = reinterpret_cast<PFNEGLGETPLATFORMDISPLAYEXTPROC>(
      eglGetProcAddress("eglGetPlatformDisplayEXT"));
  if (!query_devices || !platform_display)
    throw std::runtime_error("EGL device enumeration extensions are unavailable");
  if (!query_devices(max_devices, devices, &device_count) || device_count < 0 || device_count > max_devices)
    throw std::runtime_error("EGL device enumeration failed");
  for (EGLint index = 0; index < device_count; ++index) {
    EGLDisplay display = platform_display(EGL_PLATFORM_DEVICE_EXT, devices[index], nullptr);
    if (display == EGL_NO_DISPLAY) continue;
    auto existing = egl_display_users.find(display);
    if (existing != egl_display_users.end()) {
      ++existing->second;
      egl_display = display;
      break;
    }
    EGLint major = 0, minor = 0;
    if (eglInitialize(display, &major, &minor) == EGL_TRUE) {
      egl_display = display;
      egl_display_users[display] = 1;
      break;
    }
  }
  if (egl_display == EGL_NO_DISPLAY) throw std::runtime_error("EGL display initialization failed");
  if (eglBindAPI(EGL_OPENGL_API) != EGL_TRUE) throw std::runtime_error("EGL OpenGL API unavailable");
  constexpr EGLint attributes[] = {EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8,
      EGL_SURFACE_TYPE, EGL_PBUFFER_BIT, EGL_RENDERABLE_TYPE, EGL_OPENGL_BIT, EGL_NONE};
  EGLint config_count = 0;
  EGLConfig config{};
  if (eglChooseConfig(egl_display, attributes, &config, 1, &config_count) != EGL_TRUE || config_count != 1)
    throw std::runtime_error("EGL has no matching OpenGL pbuffer configuration");
  const EGLint surface_attributes[] = {EGL_WIDTH, context_width, EGL_HEIGHT, context_height, EGL_NONE};
  egl_surface = eglCreatePbufferSurface(egl_display, config, surface_attributes);
  if (egl_surface == EGL_NO_SURFACE) throw std::runtime_error("EGL pbuffer creation failed");
  egl_context = eglCreateContext(egl_display, config, EGL_NO_CONTEXT, nullptr);
  if (egl_context == EGL_NO_CONTEXT) throw std::runtime_error("EGL context creation failed");
  if (eglMakeCurrent(egl_display, egl_surface, egl_surface, egl_context) != EGL_TRUE)
    throw std::runtime_error("EGL context activation failed");
#define SDL_PROC(ret, func, params)                                       \
  do {                                                                    \
    mapping.func = reinterpret_cast<decltype(mapping.func)>(eglGetProcAddress(#func)); \
    if (!mapping.func) throw std::runtime_error("Missing EGL GL function: " #func); \
  } while (false);
#include "sdl_glfuncs.h"
#undef SDL_PROC
  *functions_ = mapping;
}
#endif

void OpenGLRenderer3D::DestroyIBLResources() {
  if (iblTextures_[0] || iblTextures_[1] ||
      iblTextures_[2] || iblTextures_[3]) {
    mapping.glDeleteTextures(4, iblTextures_.data());
  }
  iblTextures_.fill(0);
  iblReady_ = false;
}

void OpenGLRenderer3D::CreateIBLResources(
    const std::deque<LightQueueEntry> &lights) {
  std::array<float, 6> lightParameters{0.38f, 0.24f, 0.89f,
                                       1.0f, 0.94f, 0.82f};
  float brightest = -1.0f;
  for (const LightQueueEntry &light : lights) {
    if (light.type != 0) continue;
    const float power = light.color.coords[0] + light.color.coords[1] +
                        light.color.coords[2];
    const float x = light.position.coords[0];
    const float y = light.position.coords[1];
    const float z = light.position.coords[2];
    const float distance = std::sqrt(x*x + y*y + z*z);
    if (power <= brightest || distance < 1e-4f) continue;
    brightest = power;
    lightParameters = {x/distance, y/distance, z/distance,
                       std::clamp(light.color.coords[0], 0.0f, 4.0f),
                       std::clamp(light.color.coords[1], 0.0f, 4.0f),
                       std::clamp(light.color.coords[2], 0.0f, 4.0f)};
  }
  if (iblReady_) {
    bool same = true;
    for (size_t i = 0; i < lightParameters.size(); ++i)
      same &= std::abs(iblLightParameters_[i] - lightParameters[i]) < 1e-3f;
    if (same) return;
    DestroyIBLResources();
  }

  constexpr int environmentSize = 128;
  constexpr int irradianceSize = 32;
  constexpr int prefilterSize = 128;
  constexpr int prefilterLevels = 5;
  constexpr int lutSize = 128;
  GLint previousFramebuffer = 0;
  GLint previousViewport[4]{};
  GLint previousActiveTexture = GL_TEXTURE0;
  GLint previousVAO = 0;
  mapping.glGetIntegerv(GL_FRAMEBUFFER_BINDING, &previousFramebuffer);
  mapping.glGetIntegerv(GL_VIEWPORT, previousViewport);
  mapping.glGetIntegerv(GL_ACTIVE_TEXTURE, &previousActiveTexture);
  mapping.glGetIntegerv(GL_VERTEX_ARRAY_BINDING, &previousVAO);
  const GLboolean srgbWasEnabled = mapping.glIsEnabled(GL_FRAMEBUFFER_SRGB);
  GLuint captureFramebuffer = 0;
  auto restore = [&] {
    mapping.glBindVertexArray(static_cast<GLuint>(previousVAO));
    BindFrameBuffer(previousFramebuffer);
    SetViewport(previousViewport[0], previousViewport[1],
                previousViewport[2], previousViewport[3]);
    SetTextureUnit(previousActiveTexture - GL_TEXTURE0);
    SetFramebufferGammaCorrection(srgbWasEnabled == GL_TRUE);
  };
  try {
    if (mapping.glGetError() != GL_NO_ERROR)
      throw std::runtime_error("OpenGL error before IBL preprocessing");
    SetTextureUnit(0);
    mapping.glGenTextures(4, iblTextures_.data());
    auto setupCube = [&](GLuint texture, int size, int levels,
                         bool mipFilter) {
      mapping.glBindTexture(GL_TEXTURE_CUBE_MAP, texture);
      mapping.glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S,
                             GL_CLAMP_TO_EDGE);
      mapping.glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T,
                             GL_CLAMP_TO_EDGE);
      mapping.glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R,
                             GL_CLAMP_TO_EDGE);
      mapping.glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER,
                             mipFilter ? GL_LINEAR_MIPMAP_LINEAR : GL_LINEAR);
      mapping.glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER,
                             GL_LINEAR);
      mapping.glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAX_LEVEL,
                             levels - 1);
      for (int level = 0; level < levels; ++level)
        for (int face = 0; face < 6; ++face)
          mapping.glTexImage2D(GL_TEXTURE_CUBE_MAP_POSITIVE_X + face,
              level, GL_RGBA16F, std::max(size >> level, 1),
              std::max(size >> level, 1), 0, GL_RGBA, GL_FLOAT, nullptr);
    };
    setupCube(iblTextures_[0], environmentSize, 8, true);
    setupCube(iblTextures_[1], irradianceSize, 1, false);
    setupCube(iblTextures_[2], prefilterSize, prefilterLevels, true);
    mapping.glBindTexture(GL_TEXTURE_CUBE_MAP, 0);
    BindTexture(iblTextures_[3]);
    mapping.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    mapping.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    mapping.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    mapping.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    mapping.glTexImage2D(GL_TEXTURE_2D, 0, GL_RG16F, lutSize, lutSize,
                         0, GL_RG, GL_FLOAT, nullptr);
    BindTexture(0);

    mapping.glGenFramebuffers(1, &captureFramebuffer);
    BindFrameBuffer(captureFramebuffer);
    const GLenum attachment = GL_COLOR_ATTACHMENT0;
    mapping.glDrawBuffers(1, &attachment);
    SetFramebufferGammaCorrection(false);
    SetDepthTesting(false);
    SetDepthMask(false);
    SetCullingMode(e_CullingMode_Off);
    SetBlendingMode(e_BlendingMode_Off);

    auto drawFace = [&](const std::string &shader, GLuint texture,
                        int face, int level, int size) {
      mapping.glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
          GL_TEXTURE_CUBE_MAP_POSITIVE_X + face, texture, level);
      if (mapping.glCheckFramebufferStatus(GL_FRAMEBUFFER) !=
          GL_FRAMEBUFFER_COMPLETE)
        throw std::runtime_error("IBL cubemap framebuffer incomplete");
      SetViewport(0, 0, size, size);
      SetUniformInt(shader, "faceIndex", face);
      mapping.glBindVertexArray(quadBuffer.vertexArrayID);
      mapping.glDrawArrays(GL_TRIANGLES, 0, 6);
      mapping.glBindVertexArray(0);
    };

    UseShader("ibl_environment");
    SetUniformFloat3("ibl_environment", "sunDirection", lightParameters[0],
                     lightParameters[1], lightParameters[2]);
    SetUniformFloat3("ibl_environment", "sunColor", lightParameters[3],
                     lightParameters[4], lightParameters[5]);
    for (int face = 0; face < 6; ++face)
      drawFace("ibl_environment", iblTextures_[0], face, 0, environmentSize);
    mapping.glBindTexture(GL_TEXTURE_CUBE_MAP, iblTextures_[0]);
    mapping.glGenerateMipmap(GL_TEXTURE_CUBE_MAP);

    UseShader("ibl_irradiance");
    for (int face = 0; face < 6; ++face)
      drawFace("ibl_irradiance", iblTextures_[1], face, 0, irradianceSize);

    UseShader("ibl_prefilter");
    SetUniformFloat("ibl_prefilter", "resolution", environmentSize);
    for (int level = 0; level < prefilterLevels; ++level) {
      SetUniformFloat("ibl_prefilter", "roughness",
                      float(level) / float(prefilterLevels - 1));
      for (int face = 0; face < 6; ++face)
        drawFace("ibl_prefilter", iblTextures_[2], face, level,
                 std::max(prefilterSize >> level, 1));
    }
    mapping.glBindTexture(GL_TEXTURE_CUBE_MAP, 0);

    UseShader("ibl_brdf_lut");
    mapping.glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0,
                                   GL_TEXTURE_2D, iblTextures_[3], 0);
    if (mapping.glCheckFramebufferStatus(GL_FRAMEBUFFER) !=
        GL_FRAMEBUFFER_COMPLETE)
      throw std::runtime_error("IBL BRDF framebuffer incomplete");
    SetViewport(0, 0, lutSize, lutSize);
    mapping.glBindVertexArray(quadBuffer.vertexArrayID);
    mapping.glDrawArrays(GL_TRIANGLES, 0, 6);
    mapping.glBindVertexArray(0);
    if (mapping.glGetError() != GL_NO_ERROR)
      throw std::runtime_error("OpenGL error during IBL preprocessing");

    mapping.glDeleteFramebuffers(1, &captureFramebuffer);
    captureFramebuffer = 0;
    UseShader("");
    restore();
    iblLightParameters_ = lightParameters;
    iblReady_ = true;
  } catch (...) {
    if (captureFramebuffer)
      mapping.glDeleteFramebuffers(1, &captureFramebuffer);
    UseShader("");
    restore();
    DestroyIBLResources();
    throw;
  }
}

bool OpenGLRenderer3D::CreateContext(int width, int height, int bpp,
                                     bool fullscreen) {
  this->context_width = width;
  this->context_height = height;
  this->context_bpp = bpp;

  // default values
  this->cameraNear = 30.0;
  this->cameraFar = 270.0;
#ifdef __linux__
  if (!getenv("DISPLAY")) {
    std::cout << "No DISPLAY defined, doing off-screen rendering" << std::endl;
    CreateContextEgl();
  } else {
    CreateContextSdl();
  }
#else
  CreateContextSdl();
#endif
  largest_supported_anisotropy = 2;
  mapping.glGetFloatv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT,
                      &largest_supported_anisotropy);

  mapping.glDisable(GL_MULTISAMPLE);
  mapping.glCullFace(GL_BACK);

  // shaders
  LoadShader("simple", "media/shaders/simple");
  LoadShader("pbr_geometry", "media/shaders/pbr_geometry");
  LoadShader("lighting", "media/shaders/lighting");
  LoadShader("ambient", "media/shaders/ambient");
  LoadShader("zphase", "media/shaders/zphase");
  LoadShader("postprocess", "media/shaders/postprocess");
  LoadShader("overlay", "media/shaders/overlay");
  
  // 2026-09-03 Phase 12-15: 新渲染管线着色器
  LoadShader("pbr", "media/shaders/pbr");
  LoadShader("ibl_environment", "media/shaders/ibl_environment");
  LoadShader("ibl_irradiance", "media/shaders/ibl_irradiance");
  LoadShader("ibl_prefilter", "media/shaders/ibl_prefilter");
  LoadShader("ibl_brdf_lut", "media/shaders/ibl_brdf_lut");
  LoadShader("ibl_composition", "media/shaders/ibl_composition");
  LoadShader("tonemapping", "media/shaders/tonemapping");
  LoadShader("auto_exposure", "media/shaders/auto_exposure");
  LoadShader("csm_depth", "media/shaders/csm_depth");
  LoadShader("csm_sampling", "media/shaders/csm_sampling");
  LoadShader("vsm_depth", "media/shaders/vsm_depth");
  LoadShader("vsm_shadow", "media/shaders/vsm_shadow");
  LoadShader("blur", "media/shaders/blur");
  LoadShader("bloom", "media/shaders/bloom");
  LoadShader("ssr", "media/shaders/ssr");
  LoadShader("motion_blur", "media/shaders/motion_blur");
  LoadShader("fxaa", "media/shaders/fxaa");

  currentShader = shaders.begin();

  SDL_Surface *noise = IMG_LoadBmp("media/shaders/noise.png");
  noiseTexID =
      CreateTexture(e_InternalPixelFormat_RGB8, e_PixelFormat_RGB, noise->w,
                    noise->h, false, true, false, false, false);
  UpdateTexture(noiseTexID, noise, false, false);
  SDL_FreeSurface(noise);

  // create buffers for overlay and simple quad rendering to use shaders instead
  // of fixed pipeline.
  InitializeOverlayAndQuadBuffers();

  mapping.glClearColor(0, 0, 0, 0);
  mapping.glClearDepth(1.0);
  mapping.glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
  mapping.glDisable(GL_MULTISAMPLE);
  return true;
}

void OpenGLRenderer3D::Exit() {
  DO_VALIDATION;
  DestroyIBLResources();
  DeleteTexture(noiseTexID);

  std::map<std::string, Shader>::iterator shaderIter = shaders.begin();
  while (shaderIter != shaders.end()) {
    DO_VALIDATION;
    mapping.glDeleteShader((*shaderIter).second.vertexShaderID);
    mapping.glDeleteShader((*shaderIter).second.fragmentShaderID);
    mapping.glDeleteProgram((*shaderIter).second.programID);
    shaderIter++;
  }

  currentShader = shaders.end();
  DeleteSimpleVertexBuffer(overlayBuffer);
  DeleteSimpleVertexBuffer(quadBuffer);

  // assert(views.size() == 0);
}

int OpenGLRenderer3D::CreateView(float x_percent, float y_percent,
                                 float width_percent, float height_percent) {
  DO_VALIDATION;

  View view;

  view.target = e_ViewRenderTarget_Context;
  view.targetTexID = 0;
  view.x = int(floor(x_percent * 0.01 * context_width));
  view.y = int(floor(y_percent * 0.01 * context_height));
  view.width = int(floor(width_percent * 0.01 * context_width));
  view.height = int(floor(height_percent * 0.01 * context_height));

  // init FBO

  int gBufWidth = view.width;
  int gBufHeight = view.height;

  view.gBufferID = CreateFrameBuffer();
  BindFrameBuffer(view.gBufferID);

  // texture buffers
  view.gBuffer_DepthTexID = CreateTexture(
      e_InternalPixelFormat_DepthComponent16, e_PixelFormat_DepthComponent,
      gBufWidth, gBufHeight, false, false, false, false, false);
  SetFrameBufferTexture2D(e_TargetAttachment_Depth, view.gBuffer_DepthTexID);

  view.gBuffer_AlbedoTexID =
      CreateTexture(e_InternalPixelFormat_RGBA16F, e_PixelFormat_RGBA,
                    gBufWidth, gBufHeight, false, false, false, false, false);
  SetFrameBufferTexture2D(e_TargetAttachment_Color0, view.gBuffer_AlbedoTexID);

  view.gBuffer_NormalTexID =
      CreateTexture(e_InternalPixelFormat_RGBA16F, e_PixelFormat_RGBA,
                    gBufWidth, gBufHeight, false, false, false, false, false);
  SetFrameBufferTexture2D(e_TargetAttachment_Color1, view.gBuffer_NormalTexID);

  view.gBuffer_AuxTexID =
      CreateTexture(e_InternalPixelFormat_RGBA16F, e_PixelFormat_RGBA,
                    gBufWidth, gBufHeight, false, false, false, false, false);
  SetFrameBufferTexture2D(e_TargetAttachment_Color2, view.gBuffer_AuxTexID);

  std::vector<e_TargetAttachment> targets;
  targets.push_back(e_TargetAttachment_Color0);
  targets.push_back(e_TargetAttachment_Color1);
  targets.push_back(e_TargetAttachment_Color2);
  SetRenderTargets(targets);
  targets.clear();

  if (!CheckFrameBufferStatus())
    Log(e_FatalError, "OpenGLRenderer3D", "CreateView",
        "Could not create G-buffer");

  BindFrameBuffer(0);

  targets.push_back(e_TargetAttachment_Back);
  SetRenderTargets(targets);
  targets.clear();

  // accumulation buffer

  int accumBufWidth = view.width;
  int accumBufHeight = view.height;

  view.accumBufferID = CreateFrameBuffer();
  BindFrameBuffer(view.accumBufferID);

  view.accumBuffer_AccumTexID = CreateTexture(
      e_InternalPixelFormat_RGBA16F, e_PixelFormat_RGBA, accumBufWidth,
      accumBufHeight, false, false, false, false, false);
  SetFrameBufferTexture2D(e_TargetAttachment_Color0,
                          view.accumBuffer_AccumTexID);

  // Modifier shaders preserve only edge strength (R) and SSAO (G).
  // Retain their half-float representation without allocating unused B/A.
  view.accumBuffer_ModifierTexID = CreateTexture(
      e_InternalPixelFormat_RG16F, e_PixelFormat_RG, accumBufWidth,
      accumBufHeight, false, false, false, false, false);
  SetFrameBufferTexture2D(e_TargetAttachment_Color1,
                          view.accumBuffer_ModifierTexID);

  targets.push_back(e_TargetAttachment_Color0);
  targets.push_back(e_TargetAttachment_Color1);
  SetRenderTargets(targets);
  targets.clear();

  if (!CheckFrameBufferStatus())
    Log(e_FatalError, "OpenGLRenderer3D", "CreateView",
        "Could not create Accumulation buffer");

  BindFrameBuffer(0);

  targets.push_back(e_TargetAttachment_Back);
  SetRenderTargets(targets);
  targets.clear();

  views.push_back(view);

  return views.size() - 1;
}

View &OpenGLRenderer3D::GetView(int viewID) {
  DO_VALIDATION;
  return views.at(viewID);
}

void OpenGLRenderer3D::DeleteView(int viewID) {
  DO_VALIDATION;

  View *view = &views.at(viewID);

  BindFrameBuffer(view->gBufferID);
  SetFrameBufferTexture2D(e_TargetAttachment_Depth, 0);
  SetFrameBufferTexture2D(e_TargetAttachment_Color0, 0);
  SetFrameBufferTexture2D(e_TargetAttachment_Color1, 0);
  SetFrameBufferTexture2D(e_TargetAttachment_Color2, 0);
  DeleteFrameBuffer(view->gBufferID);

  BindFrameBuffer(view->accumBufferID);
  SetFrameBufferTexture2D(e_TargetAttachment_Color0, 0);
  SetFrameBufferTexture2D(e_TargetAttachment_Color1, 0);
  DeleteFrameBuffer(view->accumBufferID);

  DeleteTexture(view->gBuffer_AlbedoTexID);
  DeleteTexture(view->gBuffer_NormalTexID);
  DeleteTexture(view->gBuffer_DepthTexID);
  DeleteTexture(view->gBuffer_AuxTexID);

  DeleteTexture(view->accumBuffer_AccumTexID);
  DeleteTexture(view->accumBuffer_ModifierTexID);
  for (int i = 0; i < 2; ++i) {
    if (view->postBloomFrameBufferID[i]) {
      BindFrameBuffer(view->postBloomFrameBufferID[i]);
      SetFrameBufferTexture2D(e_TargetAttachment_Color0, 0);
      DeleteFrameBuffer(view->postBloomFrameBufferID[i]);
      DeleteTexture(view->postBloomTextureID[i]);
      view->postBloomFrameBufferID[i] = 0;
      view->postBloomTextureID[i] = 0;
    }
  }
  if (view->postToneFrameBufferID) {
    BindFrameBuffer(view->postToneFrameBufferID);
    SetFrameBufferTexture2D(e_TargetAttachment_Color0, 0);
    DeleteFrameBuffer(view->postToneFrameBufferID);
    DeleteTexture(view->postToneTextureID);
    view->postToneFrameBufferID = 0;
    view->postToneTextureID = 0;
  }
  for (int i = 0; i < 2; ++i) {
    if (view->postExposureFrameBufferID[i]) {
      BindFrameBuffer(view->postExposureFrameBufferID[i]);
      SetFrameBufferTexture2D(e_TargetAttachment_Color0, 0);
      DeleteFrameBuffer(view->postExposureFrameBufferID[i]);
      DeleteTexture(view->postExposureTextureID[i]);
      view->postExposureFrameBufferID[i] = 0;
      view->postExposureTextureID[i] = 0;
    }
  }
  BindFrameBuffer(0);
}

  // general

void OpenGLRenderer3D::SetCullingMode(e_CullingMode cullingMode) {
  DO_VALIDATION;
  
  // 2026-09-03 渲染优化：状态缓存
  if (cachingEnabled_ && stateCache.cullingMode == cullingMode) {
    return; // 状态未改变，跳过 OpenGL 调用
  }
  stateCache.cullingMode = cullingMode;

  switch (cullingMode) {
    DO_VALIDATION;

    case e_CullingMode_Off:
      mapping.glDisable(GL_CULL_FACE);
      break;

    case e_CullingMode_Front:
      mapping.glEnable(GL_CULL_FACE);
      mapping.glCullFace(GL_FRONT);
      break;

    case e_CullingMode_Back:
      mapping.glEnable(GL_CULL_FACE);
      mapping.glCullFace(GL_BACK);
      break;
  }
}

void OpenGLRenderer3D::SetBlendingMode(e_BlendingMode blendingMode) {
  DO_VALIDATION;
  
  // 2026-09-03 渲染优化：状态缓存
  if (cachingEnabled_ && stateCache.blendingMode == blendingMode) {
    return;
  }
  stateCache.blendingMode = blendingMode;
  
  switch (blendingMode) {
    DO_VALIDATION;

    case e_BlendingMode_Off:
      mapping.glDisable(GL_BLEND);
      break;

    case e_BlendingMode_On:
      mapping.glEnable(GL_BLEND);
      break;
  }
}

GLenum GetGLBlendingFunction(e_BlendingFunction blendingFunction) {
  DO_VALIDATION;

  GLenum GLfunc = GL_ONE;

  switch (blendingFunction) {
    DO_VALIDATION;

    case e_BlendingFunction_Zero:
      GLfunc = GL_ZERO;
      break;

    case e_BlendingFunction_One:
      GLfunc = GL_ONE;
      break;
  }

  return GLfunc;
}

void OpenGLRenderer3D::SetBlendingFunction(
    e_BlendingFunction blendingFunction1,
    e_BlendingFunction blendingFunction2) {
  DO_VALIDATION;

  GLenum func1 = GetGLBlendingFunction(blendingFunction1);
  GLenum func2 = GetGLBlendingFunction(blendingFunction2);

  mapping.glBlendFunc(func1, func2);
}

void OpenGLRenderer3D::SetDepthFunction(e_DepthFunction depthFunction) {
  DO_VALIDATION;
  
  // 2026-09-03 渲染优化：状态缓存
  if (cachingEnabled_ && stateCache.depthFunction == depthFunction) {
    return;
  }
  stateCache.depthFunction = depthFunction;
  
  switch (depthFunction) {
    DO_VALIDATION;

    case e_DepthFunction_Never:
      mapping.glDepthFunc(GL_NEVER);
      break;

    case e_DepthFunction_Equal:
      mapping.glDepthFunc(GL_EQUAL);
      break;

    case e_DepthFunction_Greater:
      mapping.glDepthFunc(GL_GREATER);
      break;

    case e_DepthFunction_Less:
      mapping.glDepthFunc(GL_LESS);
      break;

    case e_DepthFunction_GreaterOrEqual:
      mapping.glDepthFunc(GL_GEQUAL);
      break;

    case e_DepthFunction_LessOrEqual:
      mapping.glDepthFunc(GL_LEQUAL);
      break;

    case e_DepthFunction_NotEqual:
      mapping.glDepthFunc(GL_NOTEQUAL);
      break;

    case e_DepthFunction_Always:
      mapping.glDepthFunc(GL_ALWAYS);
      break;
  }
}

void OpenGLRenderer3D::SetDepthTesting(bool OnOff) {
  DO_VALIDATION;
  
  // 2026-09-03 渲染优化：状态缓存
  if (cachingEnabled_ && stateCache.depthTesting == OnOff) {
    return;
  }
  stateCache.depthTesting = OnOff;
  
  if (OnOff) {
    DO_VALIDATION;
    mapping.glEnable(GL_DEPTH_TEST);
  } else {
    mapping.glDisable(GL_DEPTH_TEST);
  }
}

void OpenGLRenderer3D::SetDepthMask(bool OnOff) {
  DO_VALIDATION;
  
  // 2026-09-03 渲染优化：状态缓存
  if (cachingEnabled_ && stateCache.depthMask == OnOff) {
    return;
  }
  stateCache.depthMask = OnOff;
  
  if (OnOff) {
    DO_VALIDATION;
    mapping.glDepthMask(GL_TRUE);
  } else {
    mapping.glDepthMask(GL_FALSE);
  }
}

void OpenGLRenderer3D::SetTextureMode(e_TextureMode textureMode) {
  DO_VALIDATION;
  // Never called. Uses deprecated methods
  /*
  switch (textureMode) {
    DO_VALIDATION;

    case e_TextureMode_Off:
      mapping.glDisable(GL_TEXTURE_2D);
      break;

    case e_TextureMode_2D:
      mapping.glEnable(GL_TEXTURE_2D);
      break;
  }
   */
}

void OpenGLRenderer3D::SetColor(const Vector3 &color, float alpha) {
  DO_VALIDATION;
  mapping.glColor4f(color.coords[0], color.coords[1], color.coords[2], alpha);
}

void OpenGLRenderer3D::SetColorMask(bool r, bool g, bool b, bool alpha) {
  DO_VALIDATION;
  mapping.glColorMask(r, g, b, alpha);
}

void OpenGLRenderer3D::ClearBuffer(const Vector3 &color, bool clearDepth,
                                   bool clearColor) {
  DO_VALIDATION;
  // xx    glClearColor(color.coords[0], color.coords[1], color.coords[2], 0.0);
  // REDUNDANT? deprecated?
  // xx    glClearDepth(1.0f);
  // glClear((GL_COLOR_BUFFER_BIT && clearColor) | (GL_DEPTH_BUFFER_BIT &&
  // clearDepth));
  GLbitfield mask = 0;
  if (clearDepth) mask |= GL_DEPTH_BUFFER_BIT;
  if (clearColor) mask |= GL_COLOR_BUFFER_BIT;
  mapping.glClear(mask);
}

Matrix4 OpenGLRenderer3D::CreatePerspectiveMatrix(float aspectRatio,
                                                  float nearCap, float farCap) {
  DO_VALIDATION;
  // XX deprecated glMatrixMode(GL_PROJECTION);
  // XX deprecated glLoadIdentity();
  float Xnear = nearCap;
  if (Xnear == -1) Xnear = cameraNear;
  float Xfar = farCap;
  if (Xfar == -1) Xfar = cameraFar;
  // XX deprecated gluPerspective(FOV, aspectRatio, Xnear, Xfar);

  Matrix4 projectionMatrix;
  projectionMatrix.ConstructProjection(FOV, aspectRatio, Xnear, Xfar);

  return projectionMatrix;
}

Matrix4 OpenGLRenderer3D::CreateOrthoMatrix(float left, float right,
                                            float bottom, float top,
                                            float nearCap, float farCap) {
  DO_VALIDATION;
  // XX deprecated glMatrixMode(GL_PROJECTION);
  // XX deprecated glLoadIdentity();
  float Xnear = nearCap;
  if (Xnear == -1) Xnear = cameraNear;
  float Xfar = farCap;
  if (Xfar == -1) Xfar = cameraFar;
  // XX deprecated glOrtho(left, right, bottom, top, Xnear, Xfar);

  Matrix4 orthoMatrix;
  orthoMatrix.ConstructOrtho(left, right, bottom, top, Xnear, Xfar);

  return orthoMatrix;
}

  // vertex buffers

GLenum GetGLVertexBufferUsage(e_VertexBufferUsage usage) {
  DO_VALIDATION;

  GLenum GLfunc = GL_STREAM_DRAW;

  switch (usage) {
    DO_VALIDATION;

    case e_VertexBufferUsage_StreamDraw:
      GLfunc = GL_STREAM_DRAW;
      break;

    case e_VertexBufferUsage_StreamRead:
      GLfunc = GL_STREAM_READ;
      break;

    case e_VertexBufferUsage_StreamCopy:
      GLfunc = GL_STREAM_COPY;
      break;

    case e_VertexBufferUsage_StaticDraw:
      GLfunc = GL_STATIC_DRAW;
      break;

    case e_VertexBufferUsage_StaticRead:
      GLfunc = GL_STATIC_READ;
      break;

    case e_VertexBufferUsage_StaticCopy:
      GLfunc = GL_STATIC_COPY;
      break;

    case e_VertexBufferUsage_DynamicDraw:
      GLfunc = GL_DYNAMIC_DRAW;
      break;

    case e_VertexBufferUsage_DynamicRead:
      GLfunc = GL_DYNAMIC_READ;
      break;

    case e_VertexBufferUsage_DynamicCopy:
      GLfunc = GL_DYNAMIC_COPY;
      break;
  }

  return GLfunc;
}

VertexBufferID OpenGLRenderer3D::CreateVertexBuffer(
    float *vertices, unsigned int verticesDataSize,
    const std::vector<unsigned int> &c_indices, e_VertexBufferUsage usage) {
  DO_VALIDATION;
  std::vector<unsigned int> indices = c_indices;
  GLuint iid = 0;  // element indices
  unsigned int vertexArrayID = 0;

  bool pingPong = false;
  if (usage == e_VertexBufferUsage_DynamicDraw ||
      usage == e_VertexBufferUsage_DynamicRead ||
      usage == e_VertexBufferUsage_DynamicCopy ||
      usage == e_VertexBufferUsage_StreamDraw ||
      usage == e_VertexBufferUsage_StreamRead ||
      usage == e_VertexBufferUsage_StreamCopy)
    pingPong = true;
  pingPong = false;  // use orphaning instead
  int number = 1;
  if (pingPong) number = 2;

  int firstBuffer_id = 0;
  int firstArray_id = 0;

  for (int b = 0; b < number; b++) {
    DO_VALIDATION;
    GLuint vid = 0;
    mapping.glGenVertexArrays(1, &vid);
    mapping.glBindVertexArray(vid);
    vertexArrayID = vid;
    if (b == 0) firstArray_id = vertexArrayID;

    GLuint bid = 0;
    mapping.glGenBuffers(1, &bid);
    int buffer_id = bid;
    if (b == 0) firstBuffer_id = buffer_id;
    // printf("array size: %i\n", triangleCount * 3 * 3);
    mapping.glBindBuffer(GL_ARRAY_BUFFER, buffer_id);
    mapping.glBufferData(GL_ARRAY_BUFFER, verticesDataSize * sizeof(float),
                         NULL, GetGLVertexBufferUsage(usage));
    mapping.glBufferSubData(GL_ARRAY_BUFFER, 0,
                            verticesDataSize * sizeof(float), vertices);

    // generate a buffer for the indices

    if (indices.size() == 0) {
      DO_VALIDATION;
      for (unsigned int i = 0;
           i < verticesDataSize / GetTriangleMeshElementCount() / 3; i++) {
        DO_VALIDATION;
        indices.push_back(i);
      }
    }
    mapping.glGenBuffers(1, &iid);
    mapping.glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, iid);
    mapping.glBufferData(GL_ELEMENT_ARRAY_BUFFER,
                         indices.size() * sizeof(unsigned int), NULL,
                         GetGLVertexBufferUsage(usage));
    mapping.glBufferSubData(GL_ELEMENT_ARRAY_BUFFER, 0,
                            indices.size() * sizeof(unsigned int), &indices[0]);

#define BUFFER_OFFSET(i) ((char *)NULL + (i))
    for (int i = 0; i < GetTriangleMeshElementCount(); i++) {
      DO_VALIDATION;
      mapping.glVertexAttribPointer(
          (GLuint)i, 3, GL_FLOAT, GL_FALSE, 0,
          BUFFER_OFFSET(verticesDataSize / GetTriangleMeshElementCount() * i *
                        sizeof(float)));
      mapping.glEnableVertexAttribArray(i);
    }

    if (b == 1) {
      DO_VALIDATION;
      VAOReadIndex.insert(std::pair<int, int>(firstArray_id, 0));
      VBOPingPongMap.insert(std::pair<int, int>(firstBuffer_id, buffer_id));
      VAOPingPongMap.insert(std::pair<int, int>(firstArray_id, vertexArrayID));
    }
  }

  mapping.glBindVertexArray(0);

  mapping.glBindBuffer(GL_ARRAY_BUFFER, 0);
  mapping.glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

  VertexBufferID vertexBufferID;
  vertexBufferID.bufferID = firstBuffer_id;
  vertexBufferID.vertexArrayID = firstArray_id;
  vertexBufferID.elementArrayID = iid;

  // vertexArrayID = firstArray_id;
  return vertexBufferID;
}

void OpenGLRenderer3D::UpdateVertexBuffer(VertexBufferID vertexBufferID,
                                          float *vertices,
                                          unsigned int verticesDataSize) {
  DO_VALIDATION;
  int writeVertexBufferID = vertexBufferID.bufferID;
  int writeVertexArrayID = vertexBufferID.vertexArrayID;

  int pingPongReadSwitch = 0;
  // bool pingPong = false;
  std::map<int, int>::iterator pingPongIter =
      VAOReadIndex.find(vertexBufferID.vertexArrayID);
  if (pingPongIter != VAOReadIndex.end()) {
    DO_VALIDATION;
    pingPongReadSwitch = pingPongIter->second;
    // pingPong = true;

    pingPongIter->second++;
    if (pingPongIter->second == 2) pingPongIter->second = 0;
  }

  if (pingPongReadSwitch == 0) {
    DO_VALIDATION;
    pingPongIter = VBOPingPongMap.find(vertexBufferID.bufferID);
    if (pingPongIter != VBOPingPongMap.end()) {
      DO_VALIDATION;
      writeVertexBufferID = pingPongIter->second;
    }

    pingPongIter = VAOPingPongMap.find(vertexBufferID.vertexArrayID);
    if (pingPongIter != VAOPingPongMap.end()) {
      DO_VALIDATION;
      writeVertexArrayID = pingPongIter->second;
    }
  }

  mapping.glBindVertexArray((GLuint)writeVertexArrayID);
  mapping.glBindBuffer(
      GL_ARRAY_BUFFER,
      writeVertexBufferID);
  // glBufferData(GL_ARRAY_BUFFER, verticesDataSize * sizeof(float), vertices,
  // GL_DYNAMIC_DRAW);

  //    glBufferData(GL_ARRAY_BUFFER, verticesDataSize * sizeof(float), NULL,
  //    GL_DYNAMIC_DRAW);

  //    if (!pingPong) { DO_VALIDATION;
  // i don't think we can use glMapBufferRange with GL_MAP_UNSYNCHRONIZED_BIT in
  // a non-pingponged situation, but may want to test this sometimes
  //      glBufferSubData(GL_ARRAY_BUFFER, 0, verticesDataSize * sizeof(float),
  //      vertices);
  //    } else {
  // glBufferData(GL_ARRAY_BUFFER, verticesDataSize * sizeof(float), NULL,
  // GL_STREAM_DRAW); float *ptr = (float*)glMapBuffer(GL_ARRAY_BUFFER,
  // GL_WRITE_ONLY);

  // the next 2 statements, as well as the invalidate_bit stuff in the 3rd
  // statement, should do the same thing: orphaning the vertexbuffer. however,
  // on my current AMD (HD 6850), only the first seems to actually work! is this
  // an AMD driver bug? can't find anything about it on the interwebz..

  mapping.glBufferData(GL_ARRAY_BUFFER, verticesDataSize * sizeof(float), NULL,
                       GL_DYNAMIC_DRAW);
  // glInvalidateBufferData(vertexBufferID.bufferID);
  float *ptr = (float *)mapping.glMapBufferRange(
      GL_ARRAY_BUFFER, 0, verticesDataSize * sizeof(float),
      GL_MAP_WRITE_BIT |
          GL_MAP_UNSYNCHRONIZED_BIT);  // GL_MAP_INVALIDATE_BUFFER_BIT |
                                       // GL_MAP_INVALIDATE_RANGE_BIT |
  // 2026-09-01: glMapBufferRange 在某些驱动上返回 NULL（尤其无 GL context
  // 或驱动不支持 UNSYNCHRONIZED），回退到 glBufferSubData 避免 memcpy NULL crash。
  if (ptr) {
    memcpy(ptr, vertices, verticesDataSize * sizeof(float));
    mapping.glUnmapBuffer(GL_ARRAY_BUFFER);
  } else {
    mapping.glBufferSubData(GL_ARRAY_BUFFER, 0,
                            verticesDataSize * sizeof(float), vertices);
  }

  //      glBufferData(GL_ARRAY_BUFFER, verticesDataSize * sizeof(float),
  //      vertices, GL_DYNAMIC_DRAW);

  //    }

  // this fence doesn't seem necessary. the frame swap will glflush things
  // anyway, so as long as you don't update the mesh and render stuff in the
  // same frame, you should be okay. ^ investigate if this is correct thinking.
  // not sure. hairstyles seem to be late, so there is something wrong with
  // omitting the fence. if it's true, users of the engine will need to make
  // sure to not update and render in parallel. maybe make this an option? maybe
  // put something about it in a future manual?
  // GLsync syncObj = glFenceSync(GL_SYNC_GPU_COMMANDS_COMPLETE, 0);
  /*fenceoff
      // delete possible previous sync object
      std::map<int, GLsync>::iterator syncIter =
     VAOfence.find(writeVertexArrayID); if (syncIter != VAOfence.end()) {
     DO_VALIDATION; glDeleteSync(syncIter->second); VAOfence.erase(syncIter);
      }
  */
  // VAOfence.insert(std::pair<int, GLsync>(writeVertexArrayID, syncObj));

  mapping.glBindVertexArray(0);
  mapping.glBindBuffer(GL_ARRAY_BUFFER, 0);
}

void OpenGLRenderer3D::DeleteVertexBuffer(VertexBufferID vertexBufferID) {
  DO_VALIDATION;
  GLuint glVertexBufferID = vertexBufferID.bufferID;
  mapping.glDeleteBuffers(1, &glVertexBufferID);

  GLuint glElementArrayID = vertexBufferID.elementArrayID;
  mapping.glDeleteBuffers(1, &glElementArrayID);

  GLuint glVertexArrayID = vertexBufferID.vertexArrayID;
  mapping.glDeleteVertexArrays(1, &glVertexArrayID);

  std::map<int, int>::iterator pingPongIter =
      VBOPingPongMap.find(vertexBufferID.bufferID);
  if (pingPongIter != VBOPingPongMap.end()) {
    DO_VALIDATION;
    glVertexBufferID = pingPongIter->second;
    mapping.glDeleteBuffers(1, &glVertexBufferID);
    VBOPingPongMap.erase(pingPongIter);
  }

  pingPongIter = VAOPingPongMap.find(vertexBufferID.vertexArrayID);
  if (pingPongIter != VAOPingPongMap.end()) {
    DO_VALIDATION;
    glVertexArrayID = pingPongIter->second;
    mapping.glDeleteVertexArrays(1, &glVertexArrayID);
    VAOPingPongMap.erase(pingPongIter);
  }

  pingPongIter = VAOReadIndex.find(vertexBufferID.vertexArrayID);
  if (pingPongIter != VAOReadIndex.end()) {
    DO_VALIDATION;
    VAOReadIndex.erase(pingPongIter);
  }
}

void DrawBufferChunk(int startIndex, int count) {
  // 2026-09-13: preserve GL state while servicing external UI input.
  ScopedRenderService::Poll();
  DO_VALIDATION;
  // draw buffer
  if (count > 0) {
    DO_VALIDATION;
#define BUFFER_OFFSET(i) ((char *)NULL + (i))
    mapping.glDrawRangeElements(
        GL_TRIANGLES, startIndex, startIndex + count, count, GL_UNSIGNED_INT,
        BUFFER_OFFSET(startIndex * sizeof(unsigned int)));
  }
}

void OpenGLRenderer3D::RenderVertexBuffer(
    const std::deque<VertexBufferQueueEntry> &vertexBufferQueue,
    e_RenderMode renderMode) {
  DO_VALIDATION;
  VertexBuffer *vertexBuffer;
  const bool pbrGeometry = currentShader != shaders.end() &&
                           currentShader->first == "pbr_geometry";
  const std::string materialShader = pbrGeometry ? "pbr_geometry" : "simple";
  std::array<float, 6> previousMaterial{};
  bool materialInitialized = false;

// Deprecated
//  if (renderMode != e_RenderMode_GeometryOnly) {
//    DO_VALIDATION;
//    mapping.glEnable(GL_TEXTURE_2D);
//  } else {
//    mapping.glDisable(GL_TEXTURE_2D);
//  }

  signed int currentDiffuseTextureID = -1;
  signed int currentNormalTextureID = -1;
  signed int currentSpecularTextureID = -1;
  signed int currentIlluminationTextureID = -1;
  signed int currentBoundBuffer = -1;

  int bufferSwitches = 0;

  Matrix4 transform;

  std::deque<VertexBufferQueueEntry>::const_iterator vertexBufferQueueIter =
      vertexBufferQueue.begin();
  while (vertexBufferQueueIter != vertexBufferQueue.end()) {
    // 2026-09-13: bounded opportunity between complete draw batches.
    ScopedRenderService::Poll();
    DO_VALIDATION;
    const VertexBufferQueueEntry *queueEntry = &(*vertexBufferQueueIter);

    vertexBuffer = queueEntry->vertexBuffer->GetResource();
    if (currentBoundBuffer != vertexBuffer->GetVaoID()) {
      DO_VALIDATION;
      bufferSwitches++;

      int vaoID = vertexBuffer->GetVaoID();
      int pingPongReadSwitch = 0;
      std::map<int, int>::iterator pingPongIter = VAOReadIndex.find(vaoID);
      if (pingPongIter != VAOReadIndex.end()) {
        DO_VALIDATION;
        pingPongReadSwitch = pingPongIter->second;
      }

      if (pingPongReadSwitch == 1) {
        DO_VALIDATION;
        std::map<int, int>::iterator pingPongIter = VAOPingPongMap.find(vaoID);
        if (pingPongIter != VAOPingPongMap.end()) {
          DO_VALIDATION;
          vaoID = pingPongIter->second;
        }
      }

      /*
              // block on VAO update
              std::map<int, GLsync>::iterator syncIter = VAOfence.find(vaoID);
              if (syncIter != VAOfence.end()) { DO_VALIDATION;
                //glFlush();
                //glWaitSync(syncIter->second, 0, GL_TIMEOUT_IGNORED);
                GLenum returnVal = GL_WAIT_FAILED;
                while (returnVal != GL_ALREADY_SIGNALED && returnVal !=
         GL_CONDITION_SATISFIED) { DO_VALIDATION; returnVal =
         glClientWaitSync(syncIter->second, GL_SYNC_FLUSH_COMMANDS_BIT,
         1000000);
                  //returnVal = glClientWaitSync(syncIter->second, 0, 1000);
                  //if (returnVal == GL_TIMEOUT_EXPIRED) printf("TIMEOUT
         EXPIRED!\n"); assert(returnVal != GL_INVALID_VALUE);
                }
              }
      */

      currentBoundBuffer = vaoID;
      mapping.glBindVertexArray(vaoID);
      // glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, vertexBuffer->GetElementID());
      /*
              if (renderMode != e_RenderMode_GeometryOnly) { DO_VALIDATION;
                if (renderMode == e_RenderMode_Full) { DO_VALIDATION;
                }
              }
      */
    }

    // glPushMatrix();

    // slow, why?
    transform.Construct(queueEntry->position, Vector3(1, 1, 1),
                        queueEntry->rotation);
    // transform.Transpose();
    // glMultMatrixf((float*)transform.elements);
    SetMatrix("modelMatrix", transform);

    bool sequential = true;  // buffer vertexbuffer chunks until a change
                             // happens (in texture or index, for example)
    struct BufferChunk {
      BufferChunk() {
        DO_VALIDATION;
        startIndex = 0;
        count = 0;
      }
      int startIndex = 0;
      int count = 0;
    };
    BufferChunk bufferChunk;

    auto vertexBufferIter = queueEntry->vertexBufferIndices->begin();
    while (vertexBufferIter != queueEntry->vertexBufferIndices->end()) {
      DO_VALIDATION;

      // VertexBufferIndex *vbIndex = (*vertexBufferIter).get();
      const VertexBufferIndex *vbIndex = &(*vertexBufferIter);

      if (renderMode != e_RenderMode_GeometryOnly) {
        DO_VALIDATION;
        int diffuseTextureID = 0;
        int normalTextureID = 0;
        int specularTextureID = 0;
        int illuminationTextureID = 0;
        if (vbIndex->material.diffuseTexture) {
          DO_VALIDATION;
          diffuseTextureID =
              vbIndex->material.diffuseTexture->GetResource()->GetID();
        }

        if (renderMode == e_RenderMode_Full) {
          DO_VALIDATION;
          if (vbIndex->material.normalTexture) {
            DO_VALIDATION;
            normalTextureID =
                vbIndex->material.normalTexture->GetResource()->GetID();
          }
          if (vbIndex->material.specularTexture) {
            DO_VALIDATION;
            specularTextureID =
                vbIndex->material.specularTexture->GetResource()->GetID();
          }
          if (vbIndex->material.illuminationTexture) {
            DO_VALIDATION;
            illuminationTextureID =
                vbIndex->material.illuminationTexture->GetResource()->GetID();
          }
        }

        const std::array<float, 6> materialKey{
          vbIndex->material.shininess, vbIndex->material.specular_amount,
          vbIndex->material.self_illumination.coords[0],
          vbIndex->material.metallic, vbIndex->material.roughness, vbIndex->material.ao};
        const bool changedPBRMaterial = pbrGeometry &&
            (!materialInitialized || previousMaterial != materialKey);
        if (diffuseTextureID != currentDiffuseTextureID ||
            normalTextureID != currentNormalTextureID ||
            specularTextureID != currentSpecularTextureID ||
            illuminationTextureID != currentIlluminationTextureID ||
            changedPBRMaterial) {
          DO_VALIDATION;

          if (sequential) {
            DO_VALIDATION;
            DrawBufferChunk(bufferChunk.startIndex, bufferChunk.count);
            sequential = false;
          }

          bool has_normal = false;
          bool has_specular = false;
          bool has_illumination = false;
          if (normalTextureID != 0) has_normal = true;
          if (specularTextureID != 0) has_specular = true;
          if (illuminationTextureID != 0) has_illumination = true;

          if (renderMode == e_RenderMode_Full) {
            DO_VALIDATION;
            if (has_normal && normalTextureID != currentNormalTextureID) {
              DO_VALIDATION;
              SetTextureUnit(1);
              mapping.glBindTexture(GL_TEXTURE_2D, normalTextureID);
            }
            if (has_specular && specularTextureID != currentSpecularTextureID) {
              DO_VALIDATION;
              SetTextureUnit(2);
              mapping.glBindTexture(GL_TEXTURE_2D, specularTextureID);
            }
            if (has_illumination &&
                illuminationTextureID != currentIlluminationTextureID) {
              DO_VALIDATION;
              SetTextureUnit(3);
              mapping.glBindTexture(GL_TEXTURE_2D, illuminationTextureID);
            }
          }

          SetTextureUnit(0);
          mapping.glBindTexture(GL_TEXTURE_2D, diffuseTextureID);

          if (renderMode == e_RenderMode_Full) {
            DO_VALIDATION;
            // SetUniformFloat("simple", "shininess",
            // vbIndex->material.shininess * 60 + 1); SetUniformFloat("simple",
            // "specular", vbIndex->material.specular_amount);
            // SetUniformFloat("simple", "self_illumination",
            // vbIndex->material.self_illumination.coords[0]);
            // SetUniformFloat3(materialShader, "materialparams",
            // vbIndex->material.shininess * 60 + 1,
            // vbIndex->material.specular_amount,
            // vbIndex->material.self_illumination.coords[0]);
            SetUniformFloat3(materialShader, "materialparams",
                             vbIndex->material.shininess,
                             vbIndex->material.specular_amount,
                             vbIndex->material.self_illumination.coords[0]);

            // SetUniformInt("simple", "has_normal", (int)has_normal);
            // SetUniformInt("simple", "has_specular", (int)has_specular);
            // SetUniformInt("simple", "has_illumination",
            // (int)has_illumination);
            SetUniformFloat3(materialShader, "materialbools", (int)has_normal,
                             (int)has_specular, (int)has_illumination);
          }

          if (pbrGeometry) {
            SetUniformFloat3("pbr_geometry", "materialPBR", materialKey[3],
                             materialKey[4], materialKey[5]);
            previousMaterial = materialKey;
            materialInitialized = true;
          }
          currentDiffuseTextureID = diffuseTextureID;
          currentNormalTextureID = normalTextureID;
          currentSpecularTextureID = specularTextureID;
          currentIlluminationTextureID = illuminationTextureID;
        }
      }  // if !GeometryOnly

      int start = vbIndex->startIndex;
      int count = vbIndex->size;

      // if (currentShader->first.compare("zphase") == 0) printf("drawing %i
      // elements in zphase mode\n", count);

      if (sequential)
        if (bufferChunk.startIndex + bufferChunk.count != start) {
          DO_VALIDATION;
          DrawBufferChunk(bufferChunk.startIndex, bufferChunk.count);
          sequential = false;
        }

        //if (sequential) if (vertexBufferIter + 1 == queueEntry->vertexBufferIndices.end()) sequential = false; // data end
        if (sequential) {
          DO_VALIDATION;
          // add to buffer
          bufferChunk.count += count;
        } else {
          // reset buffer
          bufferChunk.startIndex = start;
          bufferChunk.count = count;
          sequential = true;
        }

        vertexBufferIter++;

        if (sequential)
          if (vertexBufferIter == queueEntry->vertexBufferIndices->end()) {
            DO_VALIDATION;
            DrawBufferChunk(bufferChunk.startIndex, bufferChunk.count);
            sequential = false;
          }
    }

      vertexBufferQueueIter++;
  }

    //printf("%i buffer switches\n", bufferSwitches);

    if (renderMode != e_RenderMode_GeometryOnly) {
      DO_VALIDATION;
      if (renderMode == e_RenderMode_Full) {
        DO_VALIDATION;
        SetTextureUnit(1);
        mapping.glBindTexture(GL_TEXTURE_2D, 0);
        SetTextureUnit(2);
        mapping.glBindTexture(GL_TEXTURE_2D, 0);
        SetTextureUnit(3);
        mapping.glBindTexture(GL_TEXTURE_2D, 0);
      }
      SetTextureUnit(0);
      mapping.glBindTexture(GL_TEXTURE_2D, 0);
      //mapping.glDisable(GL_TEXTURE_2D);
    }

    mapping.glBindVertexArray(0);
}

  // lights

void OpenGLRenderer3D::SetLight(const Vector3 &position, const Vector3 &color,
                                float radius) {
  DO_VALIDATION;
  // Deprecated functionality, everything is implemented in the shaders
  /*
  Vector3 pos = position;

  // printf("%f %f %f\n", cameraPos.coords[0], cameraPos.coords[1],
  // cameraPos.coords[2]);

  GLfloat positionF[4] = {pos.coords[0], pos.coords[1], pos.coords[2], 1.0};
  mapping.glLightfv(GL_LIGHT0, GL_POSITION, positionF);
  SetUniformFloat3(currentShader->first, "lightPosition", pos.coords[0],
                   pos.coords[1], pos.coords[2]);

  GLfloat diffuseF[4] = {color.coords[0], color.coords[1], color.coords[2],
                         radius};
  mapping.glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuseF);

  GLfloat specular[3] = {1, 1, 1};
  mapping.glLightfv(GL_LIGHT0, GL_SPECULAR, specular);

  mapping.glEnable(GL_LIGHT0);
   */
}

  // textures

GLenum GetGLPixelFormat(e_PixelFormat pixelFormat) {
  DO_VALIDATION;
  GLenum format = GL_RGB;

  switch (pixelFormat) {
    DO_VALIDATION;

    case e_PixelFormat_Alpha:
      format = GL_ALPHA;
      break;
    case e_PixelFormat_RGB:
      format = GL_RGB;
      break;
    case e_PixelFormat_RGBA:
      format = GL_RGBA;
      break;
    case e_PixelFormat_RG:
      format = GL_RG;
      break;
    case e_PixelFormat_DepthComponent:
      format = GL_DEPTH_COMPONENT;
      break;
    case e_PixelFormat_Luminance:
      Log(e_Error, "OpenGLRenderer3D", "GetGLPixelFormat",
          "e_PixelFormat_Luminance not supported");
      break;
  }

  return format;
}

GLenum GetGLInternalPixelFormat(e_InternalPixelFormat pixelFormat) {
  DO_VALIDATION;
  GLenum format = GL_RGB8;

  switch (pixelFormat) {
    DO_VALIDATION;

    case e_InternalPixelFormat_RGB8:
      format = GL_RGB8;
      break;
    case e_InternalPixelFormat_SRGB8:
      format = GL_SRGB8;
      break;
    case e_InternalPixelFormat_RGB16:
      format = GL_RGB16;
      break;
    case e_InternalPixelFormat_RGBA4:
      format = GL_RGBA4;
      break;
    case e_InternalPixelFormat_RGBA8:
      format = GL_RGBA8;
      break;
    case e_InternalPixelFormat_SRGBA8:
      format = GL_SRGB8_ALPHA8;
      break;
    case e_InternalPixelFormat_RGBA16:
      format = GL_RGBA16;
      break;
    case e_InternalPixelFormat_RGBA16F:
      format = GL_RGBA16F;
      break;
    case e_InternalPixelFormat_RG16F:
      format = GL_RG16F;
      break;
    case e_InternalPixelFormat_RGBA32F:
      format = GL_RGBA32F;
      break;
    case e_InternalPixelFormat_RGB5_A1:
      format = GL_RGB5_A1;
      break;
    case e_InternalPixelFormat_DepthComponent:
      format = GL_DEPTH_COMPONENT;
      break;
    case e_InternalPixelFormat_DepthComponent16:
      format = GL_DEPTH_COMPONENT16;
      break;
    case e_InternalPixelFormat_DepthComponent24:
      format = GL_DEPTH_COMPONENT24;
      break;
    case e_InternalPixelFormat_DepthComponent32:
      format = GL_DEPTH_COMPONENT32;
      break;
    case e_InternalPixelFormat_DepthComponent32F:
      format = GL_DEPTH_COMPONENT32F;
      break;
    case e_InternalPixelFormat_StencilIndex8:
      format = GL_STENCIL_INDEX8;
      break;
  }

  return format;
}

int OpenGLRenderer3D::CreateTexture(e_InternalPixelFormat internalPixelFormat,
                                    e_PixelFormat pixelFormat, int width,
                                    int height, bool alpha, bool repeat,
                                    bool mipmaps, bool filter, bool multisample,
                                    bool compareDepth) {
  DO_VALIDATION;

  /*
      if (pot(source->w) != source->w || pot(source->h) != source->h) {
     DO_VALIDATION; Log(e_Warning, "OpenGLRenderer3D", "CreateTexture",
     "Non-power-of-2 texture!");
      }
  */

  GLuint texID = 0;
  mapping.glGenTextures(1, &texID);
  BindTexture(texID);

  GLint filter_min, filter_mag;

  if (filter == true) {
    DO_VALIDATION;
    filter_min = (mipmaps) ? GL_LINEAR_MIPMAP_LINEAR : GL_LINEAR;
    filter_mag = GL_LINEAR;
  } else {
    filter_min = (mipmaps) ? GL_NEAREST_MIPMAP_NEAREST : GL_NEAREST;
    filter_mag = GL_NEAREST;
  }

  mapping.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S,
                          (repeat) ? GL_REPEAT : GL_CLAMP_TO_EDGE);
  mapping.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T,
                          (repeat) ? GL_REPEAT : GL_CLAMP_TO_EDGE);
  mapping.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filter_min);
  mapping.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filter_mag);
  if (internalPixelFormat == e_InternalPixelFormat_DepthComponent16 ||
      internalPixelFormat == e_InternalPixelFormat_DepthComponent24 ||
      internalPixelFormat == e_InternalPixelFormat_DepthComponent32 ||
      internalPixelFormat == e_InternalPixelFormat_DepthComponent32F) {
    DO_VALIDATION;
    // XXglTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_NONE);
    if (compareDepth) {
      DO_VALIDATION;
      mapping.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE,
                              GL_COMPARE_REF_TO_TEXTURE);
      mapping.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC,
                              GL_LEQUAL);
    }
    //      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    //      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    // glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);
    // glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    // Post-GLSL 1.3, DEPTH_TEXTURE_MODE is deprecated and GLSL behaves as if
    // its always set to LUMINANCE
    // glTexParameteri(GL_TEXTURE_2D, GL_DEPTH_TEXTURE_MODE, GL_INTENSITY);
    // glTexParameteri(GL_TEXTURE_2D, GL_DEPTH_TEXTURE_MODE, GL_LUMINANCE);
  }

  if (filter) {
    DO_VALIDATION;
    SetMaxAnisotropy();
  }

  if (!multisample) {
    DO_VALIDATION;
    mapping.glTexImage2D(
        GL_TEXTURE_2D, 0, GetGLInternalPixelFormat(internalPixelFormat), width,
        height, 0, GetGLPixelFormat(pixelFormat), GL_UNSIGNED_BYTE, NULL);
  } else {

  }

  /* test if this actually helps
      GLclampf prior = (width * height) / 1048576.0; // 1024*1024 tex = max
     priority
      //printf("%f\n", (pot(source->w) * pot(source->h)) / 1048576.0);
      glPrioritizeTextures(1, (const GLuint*)&texID, &prior);
  */
  BindTexture(0);

  return texID;
}

void OpenGLRenderer3D::ResizeTexture(int textureID, SDL_Surface *source,
                                     e_InternalPixelFormat internalPixelFormat,
                                     e_PixelFormat pixelFormat, bool alpha,
                                     bool mipmaps) {
  DO_VALIDATION;

  BindTexture(textureID);
  int x = 0;
  int y = 0;
  int width = source->w;
  int height = source->h;

  SDL_LockSurface(source);
  mapping.glTexImage2D(GL_TEXTURE_2D, 0,
          GetGLInternalPixelFormat(internalPixelFormat), width,
          height, 0, GetGLPixelFormat(pixelFormat),
          GL_UNSIGNED_BYTE, source->pixels);
  SDL_UnlockSurface(source);

  if (mipmaps) {
    DO_VALIDATION;
    mapping.glGenerateMipmap(GL_TEXTURE_2D);
  }

  bool repeat = false;
  bool filter = true;
  if (!mipmaps) filter = false;  // <-- todo: hack
  GLint filter_min, filter_mag;

  if (filter == true) {
    DO_VALIDATION;
    filter_min = (mipmaps) ? GL_LINEAR_MIPMAP_LINEAR : GL_LINEAR;
    filter_mag = GL_LINEAR;
    // glGetFloatv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT,
    // &largest_supported_anisotropy);
    SetMaxAnisotropy();
  } else {
    filter_min = (mipmaps) ? GL_NEAREST_MIPMAP_NEAREST : GL_NEAREST;
    filter_mag = GL_NEAREST;
  }

  mapping.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S,
                          (repeat) ? GL_REPEAT : GL_CLAMP_TO_EDGE);
  mapping.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T,
                          (repeat) ? GL_REPEAT : GL_CLAMP_TO_EDGE);
  mapping.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filter_min);
  mapping.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filter_mag);
  if (internalPixelFormat == e_InternalPixelFormat_DepthComponent16 ||
      internalPixelFormat == e_InternalPixelFormat_DepthComponent24 ||
      internalPixelFormat == e_InternalPixelFormat_DepthComponent32 ||
      internalPixelFormat == e_InternalPixelFormat_DepthComponent32F) {
    DO_VALIDATION;
    mapping.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_NONE);
    // Post-GLSL 1.3, DEPTH_TEXTURE_MODE is deprecated and GLSL behaves as if
    // its always set to LUMINANCE
    //mapping.glTexParameteri(GL_TEXTURE_2D, GL_DEPTH_TEXTURE_MODE, GL_INTENSITY);
  }

  // GLclampf prior = (width * height) / 1048576.0; // 1024*1024 tex = max
  // priority printf("%f\n", (pot(source->w) * pot(source->h)) / 1048576.0);
  // glPrioritizeTextures(1, (const GLuint*)&textureID, &prior);

  BindTexture(0);
}

void OpenGLRenderer3D::UpdateTexture(int textureID, SDL_Surface *source,
                                     bool alpha, bool mipmaps) {
  DO_VALIDATION;

  mapping.glBindTexture(GL_TEXTURE_2D, textureID);

  GLint type1 = GL_RGBA8;
  GLint type2 = (alpha) ? GL_RGBA : GL_RGB;

  int x = 0;
  int y = 0;
  int w = source->w;
  int h = source->h;

  SDL_LockSurface(source);
  mapping.glTexSubImage2D(GL_TEXTURE_2D, 0, x, y, w, h, type2, GL_UNSIGNED_BYTE,
          source->pixels);
  SDL_UnlockSurface(source);

  if (mipmaps) {
    DO_VALIDATION;
    mapping.glGenerateMipmap(GL_TEXTURE_2D);
  }
  GLint filter_min, filter_mag;

  bool filter = true;

  if (filter == true) {
    DO_VALIDATION;
    filter_min = (mipmaps) ? GL_LINEAR_MIPMAP_LINEAR : GL_LINEAR;
    filter_mag = GL_LINEAR;
    // glGetFloatv(GL_MAX_TEXTURE_MAX_ANISOTROPY_EXT,
    // &largest_supported_anisotropy);
    SetMaxAnisotropy();
  } else {
    filter_min = (mipmaps) ? GL_NEAREST_MIPMAP_NEAREST : GL_NEAREST;
    filter_mag = GL_NEAREST;
  }

  mapping.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, filter_min);
  mapping.glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, filter_mag);

  BindTexture(0);
}

void OpenGLRenderer3D::DeleteTexture(int textureID) {
  DO_VALIDATION;
  GLuint texID = textureID;
  // printf("deleting tex id: %i\n", textureID);
  mapping.glDeleteTextures(1, &texID);
}

void OpenGLRenderer3D::CopyFrameBufferToTexture(int textureID, int width,
                                                int height) {
  DO_VALIDATION;
  mapping.glBindTexture(GL_TEXTURE_2D, textureID);
  mapping.glCopyTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 0, 0, width, height);
}

void OpenGLRenderer3D::BindTexture(int textureID) {
  DO_VALIDATION;
  
  // 2026-09-03 渲染优化：纹理绑定缓存
  if (cachingEnabled_) {
    auto it = stateCache.boundTextures.find(stateCache.currentTextureUnit);
    if (it != stateCache.boundTextures.end() && it->second == textureID) {
      return; // 纹理已绑定，跳过
    }
    stateCache.boundTextures[stateCache.currentTextureUnit] = textureID;
  }
  
  mapping.glBindTexture(GL_TEXTURE_2D, (GLuint)textureID);
}

void OpenGLRenderer3D::SetTextureUnit(int textureUnit) {
  DO_VALIDATION;
  if (textureUnit != _cache_activeTextureUnit) {
    DO_VALIDATION;
    // assert(glActiveTexture);
    mapping.glActiveTexture(GL_TEXTURE0 + (GLuint)textureUnit);
    _cache_activeTextureUnit = textureUnit;
    
    // 2026-09-03 渲染优化：更新状态缓存
    if (cachingEnabled_) {
      stateCache.currentTextureUnit = textureUnit;
    }
  }
}

void OpenGLRenderer3D::SetClientTextureUnit(int textureUnit) {
  DO_VALIDATION;
  // assert(glClientActiveTexture);
  mapping.glClientActiveTexture(GL_TEXTURE0 + (GLuint)textureUnit);
}

void OpenGLRenderer3D::SetMaxAnisotropy() {
  DO_VALIDATION;
//#ifndef __APPLE__  // Can be used to check for Core Profile Mode on Linux
  mapping.glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAX_ANISOTROPY_EXT,
          largest_supported_anisotropy);
//#endif
}

  // frame buffer objects

GLenum GetGLTargetAttachment(e_TargetAttachment targetAttachment) {
  DO_VALIDATION;
  GLenum target = GL_FRONT;

  switch (targetAttachment) {
    DO_VALIDATION;

    case e_TargetAttachment_None:
      target = GL_NONE;
      break;
    case e_TargetAttachment_Front:
      target = GL_FRONT_LEFT;
      break;
    case e_TargetAttachment_Back:
      target = GL_BACK_LEFT;
      break;
    case e_TargetAttachment_Depth:
      target = GL_DEPTH_ATTACHMENT;
      break;
    case e_TargetAttachment_Stencil:
      target = GL_STENCIL_ATTACHMENT;
      break;
    case e_TargetAttachment_Color0:
      target = GL_COLOR_ATTACHMENT0;
      break;
    case e_TargetAttachment_Color1:
      target = GL_COLOR_ATTACHMENT1;
      break;
    case e_TargetAttachment_Color2:
      target = GL_COLOR_ATTACHMENT2;
      break;
    case e_TargetAttachment_Color3:
      target = GL_COLOR_ATTACHMENT3;
      break;
  }

  return target;
}

int OpenGLRenderer3D::CreateFrameBuffer() {
  DO_VALIDATION;
  GLuint id = 0;
  mapping.glGenFramebuffers(1, &id);
  return id;
}

void OpenGLRenderer3D::DeleteFrameBuffer(int fbID) {
  DO_VALIDATION;
  const GLuint id = fbID;
  mapping.glDeleteFramebuffers(1, &id);
}

void OpenGLRenderer3D::BindFrameBuffer(int fbID) {
  // 2026-09-13: preserve GL state while servicing external UI input.
  ScopedRenderService::Poll();
  DO_VALIDATION;
  
  // 2026-09-03 渲染优化：帧缓冲绑定缓存
  if (cachingEnabled_ && stateCache.currentFramebuffer == fbID) {
    return; // 帧缓冲已绑定，跳过
  }
  stateCache.currentFramebuffer = fbID;
  
  mapping.glBindFramebuffer(GL_FRAMEBUFFER, (GLuint)fbID);
}

void OpenGLRenderer3D::SetFrameBufferRenderBuffer(
    e_TargetAttachment targetAttachment, int rbID) {
  DO_VALIDATION;
  mapping.glFramebufferRenderbuffer(GL_FRAMEBUFFER,
                                    GetGLTargetAttachment(targetAttachment),
                                    GL_RENDERBUFFER, rbID);
}

void OpenGLRenderer3D::SetFrameBufferTexture2D(
    e_TargetAttachment targetAttachment, int texID) {
  DO_VALIDATION;
  mapping.glFramebufferTexture2D(GL_FRAMEBUFFER,
                                 GetGLTargetAttachment(targetAttachment),
                                 GL_TEXTURE_2D, texID, 0);
}

bool OpenGLRenderer3D::CheckFrameBufferStatus() {
  DO_VALIDATION;
  GLenum status = mapping.glCheckFramebufferStatus(GL_FRAMEBUFFER);
  if (status == GL_FRAMEBUFFER_COMPLETE) {
    DO_VALIDATION;
    return true;
  } else {
    // 2026-09-01: 降级为 Warning，由调用方决定是否 FATAL。
    // 部分驱动（如 WSL mesa）的深度-only FBO 报告不完整，但不影响渲染。
    Log(e_Warning, "OpenGLRenderer3D", "CheckFrameBufferStatus",
        "Framebuffer error state #" + int_to_str(status));
    return false;
  }
}

  // render targets

void OpenGLRenderer3D::SetRenderTargets(
    std::vector<e_TargetAttachment> targetAttachments) {
  DO_VALIDATION;
#ifdef WIN32
  std::vector<GLenum> targets(targetAttachments.size());
#else
  GLenum targets[targetAttachments.size()];
#endif
  for (int i = 0; i < (signed int)targetAttachments.size(); i++) {
    DO_VALIDATION;
    targets[i] = GetGLTargetAttachment(targetAttachments[i]);
  }
#ifdef WIN32
  mapping.glDrawBuffers(targetAttachments.size(), &targets[0]);
#else
  mapping.glDrawBuffers(targetAttachments.size(), targets);
#endif
}

  // utility

void OpenGLRenderer3D::SetFOV(float angle) {
  DO_VALIDATION;
  FOV = angle;
}

void OpenGLRenderer3D::PushAttribute(int attr) {
  DO_VALIDATION;
  mapping.glPushAttrib((GLbitfield)attr);
}

void OpenGLRenderer3D::PopAttribute() {
  DO_VALIDATION;
  mapping.glPopAttrib();
}

void OpenGLRenderer3D::SetViewport(int x, int y, int width, int height) {
  DO_VALIDATION;
  mapping.glViewport(x, y, width, height);
}

void OpenGLRenderer3D::GetContextSize(int &width, int &height, int &bpp) {
  DO_VALIDATION;
  width = context_width;
  height = context_height;
  bpp = context_bpp;
}

  // shaders

void LoadGLShader(GLuint shaderID, const std::string &filename) {
  DO_VALIDATION;
  std::vector<std::string> source;
  file_to_vector(filename, source);

  std::string source_flat;
  for (int i = 0; i < (signed int)source.size(); i++) {
    DO_VALIDATION;
    source_flat.append(source[i].c_str());
    source_flat.append("\n");
  }

  const char *sourceChar = source_flat.c_str();
  mapping.glShaderSource(shaderID, 1, &sourceChar, NULL);
  mapping.glCompileShader(shaderID);

  GLint compiled = 0;
  mapping.glGetShaderiv(shaderID, GL_COMPILE_STATUS, &compiled);
  if (compiled == GL_FALSE) {
    DO_VALIDATION;
    printf("shader compilation error (%s)\n", filename.c_str());
    Log(e_Warning, "", "LoadGLShader",
        "shader compilation error (" + filename + ")");
  }

  GLint blen = 0;
  GLsizei slen = 0;
  mapping.glGetShaderiv(shaderID, GL_INFO_LOG_LENGTH, &blen);
  if (blen > 1) {
    DO_VALIDATION;
    GLchar *compiler_log = (GLchar *)malloc(blen);
    mapping.glGetShaderInfoLog(shaderID, blen, &slen, compiler_log);
    printf("shader compilation info: %s\n", compiler_log);
    Log(e_Warning, "", "LoadGLShader",
        "shader compilation info (" + filename + "):\n" +
            std::string(compiler_log));
    free(compiler_log);
  }
}

void GeneratePoissonKernel(float *kernel, unsigned int kernelSize) {
  DO_VALIDATION;

  bool usePrecalculatedSet = false;

  if (!usePrecalculatedSet || kernelSize != 32) {
    DO_VALIDATION;
    unsigned int candidateSize = 32;

#ifdef WIN32
    std::vector<Vector3> samples(kernelSize);
    std::vector<Vector3> candidates(candidateSize);
#else
    Vector3 samples[kernelSize];
    Vector3 candidates[candidateSize];
#endif

    for (unsigned int i = 0; i < kernelSize; i++) {
      DO_VALIDATION;

      // first, create a set of candidates. all these are on the 'hull' of a
      // hemisphere.

      for (unsigned int candidate = 0; candidate < candidateSize; candidate++) {
        DO_VALIDATION;
        // http://www.pouet.net/topic.php?which=9613&page=1 (evenly distributed
        // points on hemisphere) "To generate uniformly distributed random
        // points on a sphere, you generate them on a unit cylinder (but not the
        // caps), and project onto the sphere. While it's not intuitive to see,
        // this actually gives uniform distribution." (also see page 2 for
        // corrections!)
        float s = random_non_determ(0.0f, 2.0f * pi);
        float t = random_non_determ(-1.0f, 1.0f);
        float m = std::sqrt(1.0f - t * t);
        candidates[candidate] = Vector3(std::sin(s) * m, std::cos(s) * m,
                                        fabs(t));  // fabs for hemi
      }

      // second, pick the candidate furthest away from the samples already
      // there. this will distribute them evenly all over the hull.

      int furthestCandidateID = 0;
      float furthestCandidateDistance = 0.0f;
      for (unsigned int candidate = 0; candidate < candidateSize; candidate++) {
        DO_VALIDATION;
        float distanceToClosestSample = 1.0f;
        for (unsigned int x = 0; x < i; x++) {
          DO_VALIDATION;
          float distance = candidates[candidate].GetDistance(samples[x]);
          if (distance < distanceToClosestSample)
            distanceToClosestSample = distance;
        }
        if (distanceToClosestSample > furthestCandidateDistance) {
          DO_VALIDATION;
          furthestCandidateDistance = distanceToClosestSample;
          furthestCandidateID = candidate;
        }
      }

      samples[i] = candidates[furthestCandidateID];
    }

    for (unsigned int i = 0; i < kernelSize; i++) {
      DO_VALIDATION;

      // third, randomize the length, so the samples fill the volume.

      float minDistance = 0.14f;
      samples[i] =
          samples[i].GetNormalized(0) * random_non_determ(minDistance, 1.0f);

      // information around the normal vec is most useful
      samples[i] = samples[i] * 0.75f + Vector3(0, 0, 1) * 0.25f;

      kernel[i * 3 + 0] = samples[i].coords[0];
      kernel[i * 3 + 1] = samples[i].coords[1];
      kernel[i * 3 + 2] = samples[i].coords[2];

      // printf("samples[%i].Set(%f, %f, %f);\n", i, samples[i].coords[0],
      // samples[i].coords[1], samples[i].coords[2]);
    }

  } else {  // PRECALCULATED SET
#ifdef WIN32
    std::vector<Vector3> samples(kernelSize);
#else
    Vector3 samples[kernelSize];
#endif

    // these samples seem relatively close to z = 0 (much 'ground effect' on
    // flat surface)
    samples[0].Set(-0.164502, 0.198563, 0.847836);
    samples[1].Set(-0.371169, -0.311732, 0.271810);
    samples[2].Set(0.395387, -0.169534, 0.356410);
    samples[3].Set(0.199861, 0.154104, 0.106548);
    samples[4].Set(0.003958, -0.331189, 0.151894);
    samples[5].Set(-0.128020, 0.276624, 0.133732);
    samples[6].Set(-0.576721, 0.032381, 0.472200);
    samples[7].Set(0.042701, 0.189697, 0.215682);
    samples[8].Set(0.095873, -0.029585, 0.376675);
    samples[9].Set(-0.018931, -0.559727, 0.723850);
    samples[10].Set(0.354553, -0.531634, 0.250052);
    samples[11].Set(0.211686, 0.082632, 0.250673);
    samples[12].Set(-0.586181, -0.060375, 0.086480);
    samples[13].Set(0.529458, -0.009977, 0.084485);
    samples[14].Set(-0.452887, -0.303541, 0.721515);
    samples[15].Set(-0.223906, 0.180655, 0.100284);
    samples[16].Set(-0.278485, -0.709826, 0.082907);
    samples[17].Set(0.195230, 0.204728, 0.573875);
    samples[18].Set(-0.426917, 0.460452, 0.610940);
    samples[19].Set(0.115942, -0.134919, 0.290054);
    samples[20].Set(-0.089691, -0.266767, 0.910242);
    samples[21].Set(0.259113, 0.638836, 0.159923);
    samples[22].Set(0.621548, -0.384182, 0.089235);
    samples[23].Set(0.261258, 0.331540, 0.306923);
    samples[24].Set(0.170094, -0.678424, 0.471292);
    samples[25].Set(-0.398759, -0.300976, 0.082431);
    samples[26].Set(-0.291338, 0.080905, 0.159125);
    samples[27].Set(-0.391219, 0.082053, 0.638896);
    samples[28].Set(0.051567, 0.476222, 0.765788);
    samples[29].Set(-0.181921, 0.545340, 0.430360);
    samples[30].Set(0.542024, 0.161835, 0.173717);
    samples[31].Set(-0.059420, 0.778527, 0.233026);

    Vector3 average;
    for (unsigned int i = 0; i < kernelSize; i++) {
      DO_VALIDATION;
      average += samples[i];
    }
    average /= kernelSize;
    Vector3 newAverage;
    for (unsigned int i = 0; i < kernelSize; i++) {
      DO_VALIDATION;
      samples[i] -= average.Get2D();
      kernel[i * 3 + 0] = samples[i].coords[0];
      kernel[i * 3 + 1] = samples[i].coords[1];
      kernel[i * 3 + 2] = samples[i].coords[2];
      newAverage += samples[i];
    }
    newAverage /= kernelSize;
  }
}

void OpenGLRenderer3D::LoadShader(const std::string &name,
                                  const std::string &filename) {
  DO_VALIDATION;
  GLint info = 0;

  Shader shader;
  shader.name = filename;

  shader.vertexShaderID = mapping.glCreateShader(GL_VERTEX_SHADER);
  LoadGLShader(shader.vertexShaderID, filename + ".vert");
  mapping.glGetShaderiv(shader.vertexShaderID, GL_COMPILE_STATUS, &info);
  if (info != GL_TRUE || mapping.glIsShader(shader.vertexShaderID) != GL_TRUE) {
    DO_VALIDATION;
    printf("%d %d\n", info, mapping.glIsShader(shader.vertexShaderID));
    // 2026-09-09: unwind startup so the environment releases its GL context.
    // Log(e_FatalError, "OpenGLRenderer3D", "LoadShader",
    // "1Could not compile vertex program: " + name);
    throw std::runtime_error("Could not compile vertex program: " + name);
  }

  shader.fragmentShaderID = mapping.glCreateShader(GL_FRAGMENT_SHADER);
  LoadGLShader(shader.fragmentShaderID, filename + ".frag");
  mapping.glGetShaderiv(shader.fragmentShaderID, GL_COMPILE_STATUS, &info);
  if (info != GL_TRUE ||
      mapping.glIsShader(shader.fragmentShaderID) != GL_TRUE) {
    DO_VALIDATION;
    // 2026-09-09: unwind startup so the environment releases its GL context.
    // Log(e_FatalError, "OpenGLRenderer3D", "LoadShader",
    // "2Could not compile fragment program: " + name);
    throw std::runtime_error("Could not compile fragment program: " + name);
  }

  shader.programID = mapping.glCreateProgram();
  mapping.glAttachShader(shader.programID, shader.vertexShaderID);
  mapping.glAttachShader(shader.programID, shader.fragmentShaderID);

  shaders.insert(std::pair<std::string, Shader>(name, shader));

  if (name == "zphase") {
    DO_VALIDATION;
    mapping.glBindAttribLocation(shader.programID, 0, "position");
    mapping.glBindFragDataLocation(shader.programID, 0, "stdout");
  }
  if (name == "simple" || name == "pbr_geometry") {
    DO_VALIDATION;
    mapping.glBindAttribLocation(shader.programID, 0, "position");
    mapping.glBindAttribLocation(shader.programID, 1, "normal");
    mapping.glBindAttribLocation(shader.programID, 2, "texcoord");
    mapping.glBindAttribLocation(shader.programID, 3, "tangent");
    mapping.glBindAttribLocation(shader.programID, 4, "bitangent");
    mapping.glBindFragDataLocation(shader.programID, 0, "stdout0");
    mapping.glBindFragDataLocation(shader.programID, 1, "stdout1");
    mapping.glBindFragDataLocation(shader.programID, 2, "stdout2");
  }
  if (name == "ambient") {
    DO_VALIDATION;
    mapping.glBindAttribLocation(shader.programID, 0, "position");
    mapping.glBindFragDataLocation(shader.programID, 0, "stdout");
  }
  if (name == "lighting") {
    DO_VALIDATION;
    mapping.glBindFragDataLocation(shader.programID, 0, "stdout0");
    mapping.glBindFragDataLocation(shader.programID, 1, "stdout1");
  }
  if (name == "postprocess") {
    DO_VALIDATION;
    mapping.glBindAttribLocation(shader.programID, 0, "position");
    mapping.glBindFragDataLocation(shader.programID, 0, "stdout");
  }
  if (name == "overlay") {
    DO_VALIDATION;
    mapping.glBindAttribLocation(shader.programID, 0, "vertex");
    mapping.glBindFragDataLocation(shader.programID, 0, "stdout");
  }
  
  // 2026-09-03 Phase 12-15: 新渲染管线着色器绑定
  if (name == "pbr") {
    DO_VALIDATION;
    mapping.glBindAttribLocation(shader.programID, 0, "position");
    mapping.glBindFragDataLocation(shader.programID, 0, "stdout0");
    mapping.glBindFragDataLocation(shader.programID, 1, "stdout1");
  }
  if (name == "ibl_environment" || name == "ibl_irradiance" ||
      name == "ibl_prefilter" || name == "ibl_brdf_lut") {
    DO_VALIDATION;
    mapping.glBindAttribLocation(shader.programID, 0, "position");
    mapping.glBindFragDataLocation(shader.programID, 0, "FragColor");
  }
  if (name == "ibl_composition") {
    DO_VALIDATION;
    mapping.glBindAttribLocation(shader.programID, 0, "position");
    mapping.glBindAttribLocation(shader.programID, 1, "normal");
    mapping.glBindAttribLocation(shader.programID, 2, "texCoord");
    mapping.glBindFragDataLocation(shader.programID, 0, "FragColor");
  }
  if (name == "tonemapping") {
    DO_VALIDATION;
    mapping.glBindAttribLocation(shader.programID, 0, "position");
    mapping.glBindAttribLocation(shader.programID, 1, "texCoord");
    mapping.glBindFragDataLocation(shader.programID, 0, "stdout");
  }
  if (name == "auto_exposure") {
    DO_VALIDATION;
    mapping.glBindAttribLocation(shader.programID, 0, "position");
    mapping.glBindAttribLocation(shader.programID, 1, "texCoord");
    mapping.glBindFragDataLocation(shader.programID, 0, "stdout");
  }
  if (name == "csm_depth") {
    DO_VALIDATION;
    mapping.glBindAttribLocation(shader.programID, 0, "position");
    mapping.glBindFragDataLocation(shader.programID, 0, "FragColor");
  }
  if (name == "csm_sampling") {
    DO_VALIDATION;
    mapping.glBindAttribLocation(shader.programID, 0, "position");
    mapping.glBindAttribLocation(shader.programID, 1, "normal");
    mapping.glBindAttribLocation(shader.programID, 2, "texCoord");
    mapping.glBindFragDataLocation(shader.programID, 0, "ShadowFactor");
  }
  if (name == "vsm_depth") {
    DO_VALIDATION;
    mapping.glBindAttribLocation(shader.programID, 0, "position");
    mapping.glBindFragDataLocation(shader.programID, 0, "FragColor");
  }
  if (name == "vsm_shadow") {
    DO_VALIDATION;
    mapping.glBindAttribLocation(shader.programID, 0, "position");
    mapping.glBindAttribLocation(shader.programID, 1, "normal");
    mapping.glBindAttribLocation(shader.programID, 2, "texCoord");
    mapping.glBindFragDataLocation(shader.programID, 0, "ShadowFactor");
  }
  if (name == "blur") {
    DO_VALIDATION;
    mapping.glBindAttribLocation(shader.programID, 0, "position");
    mapping.glBindAttribLocation(shader.programID, 1, "texCoord");
    mapping.glBindFragDataLocation(shader.programID, 0, "stdout");
  }
  if (name == "bloom") {
    DO_VALIDATION;
    mapping.glBindAttribLocation(shader.programID, 0, "position");
    mapping.glBindAttribLocation(shader.programID, 1, "texCoord");
    mapping.glBindFragDataLocation(shader.programID, 0, "stdout");
  }
  if (name == "ssr") {
    DO_VALIDATION;
    mapping.glBindAttribLocation(shader.programID, 0, "position");
    mapping.glBindAttribLocation(shader.programID, 1, "texCoord");
    mapping.glBindFragDataLocation(shader.programID, 0, "stdout");
  }
  if (name == "motion_blur") {
    DO_VALIDATION;
    mapping.glBindAttribLocation(shader.programID, 0, "position");
    mapping.glBindAttribLocation(shader.programID, 1, "texCoord");
    mapping.glBindFragDataLocation(shader.programID, 0, "stdout");
  }
  if (name == "fxaa") {
    DO_VALIDATION;
    mapping.glBindAttribLocation(shader.programID, 0, "position");
    mapping.glBindAttribLocation(shader.programID, 1, "texCoord");
    mapping.glBindFragDataLocation(shader.programID, 0, "stdout");
  }

  mapping.glLinkProgram(shader.programID);
  // 2026-09-09: compilation alone does not validate the stage interface.
  mapping.glGetProgramiv(shader.programID, GL_LINK_STATUS, &info);
  if (info != GL_TRUE) {
    GLint length = 0;
    mapping.glGetProgramiv(shader.programID, GL_INFO_LOG_LENGTH, &length);
    std::string detail(std::max(length, 1), '\0');
    mapping.glGetProgramInfoLog(shader.programID, detail.size(), nullptr, detail.data());
    throw std::runtime_error("Could not link shader program: " + name + ": " + detail);
  }

  // 2026-09-09: keep the program cache consistent with the actual binding.
  // mapping.glUseProgram(shader.programID);
  UseShader(name);

  GLint location = 0;
  if (name == "simple" || name == "pbr_geometry") {
    DO_VALIDATION;
    SetUniformInt(name, "map_albedo", 0);
    SetUniformInt(name, "map_normal", 1);
    SetUniformInt(name, "map_specular", 2);
    SetUniformInt(name, "map_illumination", 3);
  }
  if (name == "ambient") {
    DO_VALIDATION;
    SetUniformInt("ambient", "map_albedo", 0);
    SetUniformInt("ambient", "map_normal", 1);
    SetUniformInt("ambient", "map_depth", 2);  // recently swapped with aux
    SetUniformInt("ambient", "map_aux", 3);
    SetUniformInt("ambient", "map_noise", 4);

    SetUniformFloat("ambient", "contextX", (float)0.0);
    SetUniformFloat("ambient", "contextY", (float)0.0);
    SetUniformFloat("ambient", "contextWidth", (float)context_width);
    SetUniformFloat("ambient", "contextHeight", (float)context_height);

    unsigned int kernelSize = 32;
    // SetUniformInt("ambient", "SSAO_kernelSize", kernelSize);
#ifdef WIN32
    std::vector<float> SSAO_kernel(kernelSize * 3);
#else
    float SSAO_kernel[kernelSize * 3];
#endif
    GeneratePoissonKernel(&SSAO_kernel[0], kernelSize);
    SetUniformFloat3Array("ambient", "SSAO_kernel", kernelSize,
                          &SSAO_kernel[0]);
  }
  if (name == "lighting") {
    DO_VALIDATION;
    // on (at least older) nvidia cards, we can't 'skip' id's, or so it seems.
    // so make them consecutive edit ^ not sure after all if that is the case
    SetUniformInt("lighting", "map_albedo", 0);
    SetUniformInt("lighting", "map_normal", 1);
    SetUniformInt("lighting", "map_depth", 2);  // was: 3
    // SetUniformInt("lighting", "map_aux", 3); // was: 2
    SetUniformInt("lighting", "map_shadow", 7);

    SetUniformFloat("lighting", "contextX", (float)0.0);
    SetUniformFloat("lighting", "contextY", (float)0.0);
    SetUniformFloat("lighting", "contextWidth", (float)context_width);
    SetUniformFloat("lighting", "contextHeight", (float)context_height);
  }
  if (name == "postprocess") {
    DO_VALIDATION;
    SetUniformInt("postprocess", "map_accumulation", 0);
    SetUniformInt("postprocess", "map_modifier", 1);
    SetUniformInt("postprocess", "map_depth", 2);

    SetUniformFloat("postprocess", "contextX", (float)0.0);
    SetUniformFloat("postprocess", "contextY", (float)0.0);
    SetUniformFloat("postprocess", "contextWidth", (float)context_width);
    SetUniformFloat("postprocess", "contextHeight", (float)context_height);
  }
  
  // 2026-09-03 Phase 12-15: 新渲染管线着色器 uniform 设置
  if (name == "pbr") {
    DO_VALIDATION;
    SetUniformInt("pbr", "map_albedo", 0);
    SetUniformInt("pbr", "map_normal", 1);
    SetUniformInt("pbr", "map_depth", 2);
    SetUniformInt("pbr", "map_aux", 3);
    SetUniformInt("pbr", "map_shadow", 7);
  }
  if (name == "ibl_irradiance") {
    DO_VALIDATION;
    // 2026-09-09: match the sampler declared in the shader.
    // SetUniformInt("ibl_irradiance", "map_environment", 0);
    SetUniformInt("ibl_irradiance", "environmentMap", 0);
  }
  if (name == "ibl_prefilter") {
    DO_VALIDATION;
    // 2026-09-09: match the sampler declared in the shader.
    // SetUniformInt("ibl_prefilter", "map_environment", 0);
    SetUniformInt("ibl_prefilter", "environmentMap", 0);
  }
  if (name == "ibl_brdf_lut") {
    DO_VALIDATION;
    // 无纹理 uniform
  }
  if (name == "ibl_composition") {
    DO_VALIDATION;
    // The deferred pass reads the four existing G-buffer attachments first.
    // IBL resources occupy separate units once their lifecycle is implemented.
    SetUniformInt("ibl_composition", "map_albedo", 0);
    SetUniformInt("ibl_composition", "map_normal", 1);
    SetUniformInt("ibl_composition", "map_depth", 2);
    SetUniformInt("ibl_composition", "map_aux", 3);
    SetUniformInt("ibl_composition", "irradianceMap", 4);
    SetUniformInt("ibl_composition", "prefilterMap", 5);
    SetUniformInt("ibl_composition", "brdfLUT", 6);
  }
  if (name == "tonemapping") {
    DO_VALIDATION;
    SetUniformInt("tonemapping", "map_hdr", 0);
    SetUniformInt("tonemapping", "map_bloom", 1);
    SetUniformInt("tonemapping", "map_depth", 2);
    SetUniformInt("tonemapping", "map_exposure", 3);
    SetUniformInt("tonemapping", "useAutoExposure", 0);
    SetUniformFloat("tonemapping", "contextX", (float)0.0);
    SetUniformFloat("tonemapping", "contextY", (float)0.0);
    SetUniformFloat("tonemapping", "contextWidth", (float)context_width);
    SetUniformFloat("tonemapping", "contextHeight", (float)context_height);
    SetUniformFloat("tonemapping", "exposure", 1.0f);
    SetUniformFloat("tonemapping", "bloomStrength", 0.0f);
    SetUniformInt("tonemapping", "toneMappingOperator", 1); // ACES
  }
  if (name == "auto_exposure") {
    DO_VALIDATION;
    SetUniformInt("auto_exposure", "map_hdr", 0);
    SetUniformInt("auto_exposure", "map_previousExposure", 1);
    SetUniformFloat("auto_exposure", "minExposure", 0.1f);
    SetUniformFloat("auto_exposure", "maxExposure", 8.0f);
    SetUniformFloat("auto_exposure", "adaptationFactor", 0.125f);
  }
  if (name == "csm_depth") {
    DO_VALIDATION;
    // 无纹理 uniform
  }
  if (name == "csm_sampling") {
    DO_VALIDATION;
    SetUniformInt("csm_sampling", "shadowMapArray", 0);
    // 2026-09-09: inactive in this shader; setting it never affected output.
    // SetUniformInt("csm_sampling", "map_normal", 1);
    SetUniformFloat("csm_sampling", "shadowMapSize", 2048.0f);
    SetUniformFloat("csm_sampling", "shadowBias", 0.005f);
    SetUniformFloat("csm_sampling", "normalBias", 0.02f);
  }
  if (name == "vsm_depth") {
    DO_VALIDATION;
    // 无纹理 uniform
  }
  if (name == "vsm_shadow") {
    DO_VALIDATION;
    SetUniformInt("vsm_shadow", "shadowMap", 0);
    // 2026-09-09: inactive in this shader; setting it never affected output.
    // SetUniformInt("vsm_shadow", "map_normal", 1);
    // 2026-09-09: inactive in this shader; setting it never affected output.
    // SetUniformFloat("vsm_shadow", "shadowBias", 0.005f);
    // 2026-09-09: inactive in this shader; setting it never affected output.
    // SetUniformFloat("vsm_shadow", "varianceBias", 0.00001f);
  }
  if (name == "blur") {
    DO_VALIDATION;
    SetUniformInt("blur", "map_texture", 0);
    // 2026-09-09: inactive in this shader; setting it never affected output.
    // SetUniformFloat("blur", "contextX", (float)0.0);
    // 2026-09-09: inactive in this shader; setting it never affected output.
    // SetUniformFloat("blur", "contextY", (float)0.0);
    // 2026-09-09: inactive in this shader; setting it never affected output.
    // SetUniformFloat("blur", "contextWidth", (float)context_width);
    // 2026-09-09: inactive in this shader; setting it never affected output.
    // SetUniformFloat("blur", "contextHeight", (float)context_height);
  }
  if (name == "bloom") {
    DO_VALIDATION;
    SetUniformInt("bloom", "map_hdr", 0);
    SetUniformFloat2("bloom", "outputSize", (float)context_width,
                     (float)context_height);
    SetUniformFloat("bloom", "bloomThreshold", 0.5f);
  }
  if (name == "ssr") {
    DO_VALIDATION;
    SetUniformInt("ssr", "map_color", 0);
    SetUniformInt("ssr", "map_normal", 1);
    SetUniformInt("ssr", "map_depth", 2);
    // 2026-09-09: inactive in this shader; setting it never affected output.
    // SetUniformInt("ssr", "map_material", 3);
    SetUniformInt("ssr", "maxSteps", 64);
    SetUniformFloat("ssr", "maxDistance", 10.0f);
    SetUniformFloat("ssr", "thickness", 0.1f);
    // 2026-09-09: inactive in this shader; setting it never affected output.
    // SetUniformFloat("ssr", "fadeDistance", 5.0f);
  }
  if (name == "motion_blur") {
    DO_VALIDATION;
    SetUniformInt("motion_blur", "map_color", 0);
    SetUniformInt("motion_blur", "map_velocity", 1);
    SetUniformFloat("motion_blur", "blurStrength", 1.0f);
    SetUniformInt("motion_blur", "samples", 8);
  }
  if (name == "fxaa") {
    DO_VALIDATION;
    SetUniformInt("fxaa", "map_texture", 0);
    SetUniformFloat("fxaa", "fxaaReduceMin", 1.0f / 128.0f);
    SetUniformFloat("fxaa", "fxaaReduceMul", 1.0f / 8.0f);
    SetUniformFloat("fxaa", "fxaaSpanMax", 8.0f);
  }

  SetTextureUnit(0);

  UseShader("");
}

void OpenGLRenderer3D::SetFramebufferGammaCorrection(bool onOff) {
  DO_VALIDATION;
  if (onOff) {
    DO_VALIDATION;
    mapping.glEnable(GL_FRAMEBUFFER_SRGB);
  } else {
    mapping.glDisable(GL_FRAMEBUFFER_SRGB);
  }
}

void OpenGLRenderer3D::UseShader(const std::string &name) {
  DO_VALIDATION;
  std::map<std::string, Shader>::iterator shaderIter = shaders.find(name);
  if (shaderIter != shaders.end()) {
    DO_VALIDATION;
    
    // 2026-09-03 渲染优化：着色器程序缓存
    GLuint programID = (*shaderIter).second.programID;
    if (cachingEnabled_ && stateCache.currentProgram == programID) {
      currentShader = shaderIter;
      return; // 着色器已激活，跳过
    }
    stateCache.currentProgram = programID;

    currentShader = shaderIter;

    mapping.glUseProgram(programID);
  } else {
    // 2026-09-03 渲染优化：检查是否需要取消绑定
    if (cachingEnabled_ && stateCache.currentProgram == 0) {
      return;
    }
    stateCache.currentProgram = 0;
    mapping.glUseProgram(0);
  }
}

void OpenGLRenderer3D::SetUniformInt(const std::string &shaderName,
                                     const std::string &varName, int value) {
  DO_VALIDATION;
  std::map<std::string, Shader>::iterator shaderIter = shaders.find(shaderName);
  assert(shaderIter != shaders.end());

  std::map<std::string, GLint>::iterator iter =
      uniformCache.find(shaderName + "_var_" + varName);
  GLint location = 0;
  if (iter != uniformCache.end()) {
    DO_VALIDATION;
    location = iter->second;
  } else {
    location = mapping.glGetUniformLocation((*shaderIter).second.programID,
                                            varName.c_str());
    if (location == -1)
      Log(e_Error, "OpenGLRenderer3D", "SetUniformInt",
          "Uniform location for shader '" + shaderName +
              "' not found: " + varName);
    uniformCache.insert(std::pair<std::string, GLint>(
        shaderName + "_var_" + varName, location));
  }
  mapping.glUniform1i(location, value);
}

void OpenGLRenderer3D::SetUniformInt3(const std::string &shaderName,
                                      const std::string &varName, int value1,
                                      int value2, int value3) {
  DO_VALIDATION;
  std::map<std::string, Shader>::iterator shaderIter = shaders.find(shaderName);
  assert(shaderIter != shaders.end());

  std::map<std::string, GLint>::iterator iter =
      uniformCache.find(shaderName + "_var_" + varName);
  GLint location = 0;
  if (iter != uniformCache.end()) {
    DO_VALIDATION;
    location = iter->second;
  } else {
    location = mapping.glGetUniformLocation((*shaderIter).second.programID,
                                            varName.c_str());
    if (location == -1)
      Log(e_Error, "OpenGLRenderer3D", "SetUniformInt3",
          "Uniform location for shader '" + shaderName +
              "' not found: " + varName);
    uniformCache.insert(std::pair<std::string, GLint>(
        shaderName + "_var_" + varName, location));
  }
  mapping.glUniform3i(location, value1, value2, value3);
}

void OpenGLRenderer3D::SetUniformFloat(const std::string &shaderName,
                                       const std::string &varName,
                                       float value) {
  DO_VALIDATION;
  std::map<std::string, Shader>::iterator shaderIter = shaders.find(shaderName);
  assert(shaderIter != shaders.end());

  std::map<std::string, GLint>::iterator iter =
      uniformCache.find(shaderName + "_var_" + varName);
  GLint location = 0;
  if (iter != uniformCache.end()) {
    DO_VALIDATION;
    location = iter->second;
  } else {
    location = mapping.glGetUniformLocation((*shaderIter).second.programID,
                                            varName.c_str());
    if (location == -1)
      Log(e_Error, "OpenGLRenderer3D", "SetUniformFloat",
          "Uniform location for shader '" + shaderName +
              "' not found: " + varName);
    uniformCache.insert(std::pair<std::string, GLint>(
        shaderName + "_var_" + varName, location));
  }
  mapping.glUniform1f(location, value);
}

void OpenGLRenderer3D::SetUniformFloat2(const std::string &shaderName,
                                        const std::string &varName,
                                        float value1, float value2) {
  DO_VALIDATION;
  std::map<std::string, Shader>::iterator shaderIter = shaders.find(shaderName);
  assert(shaderIter != shaders.end());

  std::map<std::string, GLint>::iterator iter =
      uniformCache.find(shaderName + "_var_" + varName);
  GLint location = 0;
  if (iter != uniformCache.end()) {
    DO_VALIDATION;
    location = iter->second;
  } else {
    location = mapping.glGetUniformLocation((*shaderIter).second.programID,
                                            varName.c_str());
    if (location == -1)
      Log(e_Error, "OpenGLRenderer3D", "SetUniformFloat2",
          "Uniform location for shader '" + shaderName +
              "' not found: " + varName);
    uniformCache.insert(std::pair<std::string, GLint>(
        shaderName + "_var_" + varName, location));
  }
  mapping.glUniform2f(location, value1, value2);
}

void OpenGLRenderer3D::SetUniformFloat3(const std::string &shaderName,
                                        const std::string &varName,
                                        float value1, float value2,
                                        float value3) {
  DO_VALIDATION;
  std::map<std::string, Shader>::iterator shaderIter = shaders.find(shaderName);
  assert(shaderIter != shaders.end());

  std::map<std::string, GLint>::iterator iter =
      uniformCache.find(shaderName + "_var_" + varName);
  GLint location = 0;
  if (iter != uniformCache.end()) {
    DO_VALIDATION;
    location = iter->second;
  } else {
    location = mapping.glGetUniformLocation((*shaderIter).second.programID,
                                            varName.c_str());
    if (location == -1)
      Log(e_Error, "OpenGLRenderer3D", "SetUniformFloat3",
          "Uniform location for shader '" + shaderName +
              "' not found: " + varName);
    uniformCache.insert(std::pair<std::string, GLint>(
        shaderName + "_var_" + varName, location));
  }
  mapping.glUniform3f(location, value1, value2, value3);
}

void OpenGLRenderer3D::SetUniformFloat3Array(const std::string &shaderName,
                                             const std::string &varName,
                                             int count, float *values) {
  DO_VALIDATION;
  std::map<std::string, Shader>::iterator shaderIter = shaders.find(shaderName);
  assert(shaderIter != shaders.end());

  std::map<std::string, GLint>::iterator iter =
      uniformCache.find(shaderName + "_var_" + varName);
  GLint location = 0;
  if (iter != uniformCache.end()) {
    DO_VALIDATION;
    location = iter->second;
  } else {
    location = mapping.glGetUniformLocation((*shaderIter).second.programID,
                                            varName.c_str());
    if (location == -1)
      Log(e_Error, "OpenGLRenderer3D", "SetUniformFloat3Array",
          "Uniform location for shader '" + shaderName +
              "' not found: " + varName);
    uniformCache.insert(std::pair<std::string, GLint>(
        shaderName + "_var_" + varName, location));
  }
  mapping.glUniform3fv(location, count, values);
}

void OpenGLRenderer3D::SetUniformMatrix4(const std::string &shaderName,
                                         const std::string &varName,
                                         const Matrix4 &mat) {
  DO_VALIDATION;
  std::map<std::string, Shader>::iterator shaderIter = shaders.find(shaderName);
  assert(shaderIter != shaders.end());

  std::map<std::string, GLint>::iterator iter =
      uniformCache.find(shaderName + "_var_" + varName);
  GLint location = 0;
  if (iter != uniformCache.end()) {
    DO_VALIDATION;
    location = iter->second;
  } else {
    location = mapping.glGetUniformLocation((*shaderIter).second.programID,
                                            varName.c_str());
    if (location == -1)
      Log(e_Error, "OpenGLRenderer3D", "SetUniformMatrix4",
          "Uniform location for shader '" + shaderName +
              "' not found: " + varName);
    uniformCache.insert(std::pair<std::string, GLint>(
        shaderName + "_var_" + varName, location));
  }
  // mapping.glUniformMatrix4fv(location, 1, false,
  // (float*)mat.GetTransposed().elements);
  mapping.glUniformMatrix4fv(location, 1, true,
                             (float *)mat.elements);  // true == transposed
}

// 2026-09-09: SDL and EGL contexts both support scoped environment switching.
// void OpenGLRenderer3D::SetContext() { if (window) SDL_GL_MakeCurrent(window, context); }
// void OpenGLRenderer3D::DisableContext() { if (window) SDL_GL_MakeCurrent(window, nullptr); }
void OpenGLRenderer3D::SetContext() {
  mapping = *functions_;
  if (window) SDL_GL_MakeCurrent(window, context);
#ifdef __linux__
  else if (egl_display != EGL_NO_DISPLAY && egl_context != EGL_NO_CONTEXT)
    eglMakeCurrent(egl_display, egl_surface, egl_surface, egl_context);
#endif
}

void OpenGLRenderer3D::DisableContext() {
  if (window) SDL_GL_MakeCurrent(window, nullptr);
#ifdef __linux__
  else if (egl_display != EGL_NO_DISPLAY)
    eglMakeCurrent(egl_display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
#endif
}

const screenshoot &OpenGLRenderer3D::GetScreen() {
  // 2026-09-13: report disabled or unavailable capture instead of stale RGB.
  // return last_screen_;
  if (!GetGameConfig().capture_frames)
    throw std::logic_error("Frame capture is disabled");
  if (last_screen_.empty())
    throw std::logic_error("Render a frame after enabling frame capture");
  return last_screen_;
}

// 2026-09-03 Phase 12-15: PBR 渲染管线实现
void OpenGLRenderer3D::RenderViewPBR(View &view, const Matrix4 &projectionMatrix,
                                     const Matrix4 &viewMatrix,
                                     const Matrix4 &inverseProjectionViewMatrix,
                                     float depthParamNear, float depthParamFar,
                                     std::deque<VertexBufferQueueEntry> &visibleGeometry,
                                     std::deque<LightQueueEntry> &visibleLights,
                                     std::deque<VertexBufferQueueEntry> &skyboxes) {
  DO_VALIDATION;
  auto stage_last = std::chrono::steady_clock::now();
  auto gpu_stage = [&](const char* name) {
    glFinish();
    const auto now = std::chrono::steady_clock::now();
    const double ms = std::chrono::duration<double, std::milli>(now - stage_last).count();
    std::fprintf(stderr, "GPUSTAGE %s %.6f\n", name, ms);
    stage_last = now;
  };
  CreateIBLResources(visibleLights);
  gpu_stage("ibl_setup");
  
  std::vector<e_TargetAttachment> targets;
  
  // ============================================
  // 1. 渲染天空盒
  // ============================================
  if (skyboxes.size() > 0) {
    DO_VALIDATION;
    UseShader("");
    
    targets.push_back(e_TargetAttachment_Back);
    SetRenderTargets(targets);
    targets.clear();
    
    SetCullingMode(e_CullingMode_Back);
    SetBlendingMode(e_BlendingMode_Off);
    SetDepthFunction(e_DepthFunction_Less);
    SetDepthTesting(false);
    SetDepthMask(false);
    RenderVertexBuffer(skyboxes, e_RenderMode_Diffuse);
    SetDepthMask(true);
    SetDepthTesting(true);
  }
  
  // ============================================
  // 2. 几何阶段 (G-Buffer)
  // ============================================
  UseShader("pbr_geometry");
  
  BindFrameBuffer(view.gBufferID);
  
  SetViewport(0, 0, view.width, view.height);
  
  SetMatrix("projectionMatrix", projectionMatrix);
  SetMatrix("viewMatrix", viewMatrix);
  
  targets.push_back(e_TargetAttachment_Color0);
  targets.push_back(e_TargetAttachment_Color1);
  targets.push_back(e_TargetAttachment_Color2);
  SetRenderTargets(targets);
  targets.clear();
  
  SetCullingMode(e_CullingMode_Back);
  SetBlendingMode(e_BlendingMode_Off);
  SetDepthTesting(true);
  SetDepthFunction(e_DepthFunction_Less);
  SetDepthMask(true);
  ClearBuffer(Vector3(0, 0, 0), true, true);
  
  RenderVertexBuffer(visibleGeometry, e_RenderMode_Full);
  gpu_stage("gbuffer");

  
  // ============================================
  // 3. 光照阶段 (PBR + IBL)
  // ============================================
  BindFrameBuffer(view.accumBufferID);
  targets.push_back(e_TargetAttachment_Color0);
  targets.push_back(e_TargetAttachment_Color1);
  SetRenderTargets(targets);
  targets.clear();
  // Each HDR light accumulation pass starts from defined contents.
  ClearBuffer(Vector3(0, 0, 0), false, true);
  
  // 绑定 G-Buffer 纹理
  SetTextureUnit(1);
  BindTexture(view.gBuffer_NormalTexID);
  SetTextureUnit(2);
  BindTexture(view.gBuffer_DepthTexID);
  SetTextureUnit(3);
  BindTexture(view.gBuffer_AuxTexID);
  SetTextureUnit(0);
  BindTexture(view.gBuffer_AlbedoTexID);
  
  // 环境光 (IBL)
  SetTextureUnit(4);
  mapping.glBindTexture(GL_TEXTURE_CUBE_MAP, iblTextures_[1]);
  SetTextureUnit(5);
  mapping.glBindTexture(GL_TEXTURE_CUBE_MAP, iblTextures_[2]);
  SetTextureUnit(6);
  BindTexture(iblTextures_[3]);
  SetTextureUnit(0);
  UseShader("ibl_composition");
  
  SetUniformFloat("ibl_composition", "contextWidth", (float)view.width);
  SetUniformFloat("ibl_composition", "contextHeight", (float)view.height);
  SetUniformFloat("ibl_composition", "contextX", (float)0);
  SetUniformFloat("ibl_composition", "contextY", (float)0);
  SetUniformMatrix4("ibl_composition", "inverseProjectionViewMatrix",
                    inverseProjectionViewMatrix);
  const Vector3 iblCamera = viewMatrix.GetInverse().GetTranslation();
  SetUniformFloat3("ibl_composition", "cameraPosition", iblCamera.coords[0],
                   iblCamera.coords[1], iblCamera.coords[2]);
  
  SetDepthTesting(false);
  SetDepthMask(false);
  
  RenderOverlay2D();
  gpu_stage("ibl");
  SetTextureUnit(4);
  mapping.glBindTexture(GL_TEXTURE_CUBE_MAP, 0);
  SetTextureUnit(5);
  mapping.glBindTexture(GL_TEXTURE_CUBE_MAP, 0);
  SetTextureUnit(6);
  BindTexture(0);
  SetTextureUnit(0);
  
  // 直接光照 (PBR)
  UseShader("pbr");
  
  SetBlendingMode(e_BlendingMode_On);
  SetBlendingFunction(e_BlendingFunction_One, e_BlendingFunction_One);
  
  SetUniformFloat("pbr", "contextWidth", (float)view.width);
  SetUniformFloat("pbr", "contextHeight", (float)view.height);
  SetUniformFloat("pbr", "contextX", (float)0);
  SetUniformFloat("pbr", "contextY", (float)0);
  SetUniformMatrix4("pbr", "inverseProjectionViewMatrix", inverseProjectionViewMatrix);
  SetUniformMatrix4("pbr", "projectionMatrix", projectionMatrix);
  SetUniformMatrix4("pbr", "viewMatrix", viewMatrix);
  
  SetDepthTesting(false);
  SetDepthMask(false);
  
  RenderLights(visibleLights, projectionMatrix, viewMatrix);
  gpu_stage("lights");

  
  SetBlendingMode(e_BlendingMode_Off);
  SetDepthMask(true);
  SetCullingMode(e_CullingMode_Off);
  
  // 清理纹理绑定
  SetTextureUnit(1);
  BindTexture(0);
  SetTextureUnit(2);
  BindTexture(0);
  SetTextureUnit(3);
  BindTexture(0);
  SetTextureUnit(0);
  BindTexture(0);
  
  // ============================================
  // 4. 后处理阶段 (Tone Mapping + Bloom + FXAA)
  // Bloom works in linear HDR at half resolution before display transfer.
  const int bloomWidth = std::max(1, view.width / 2);
  const int bloomHeight = std::max(1, view.height / 2);
  if (pbrBloomEnabled_ && !view.postBloomFrameBufferID[0]) {
    for (int i = 0; i < 2; ++i) {
      view.postBloomFrameBufferID[i] = CreateFrameBuffer();
      BindFrameBuffer(view.postBloomFrameBufferID[i]);
      view.postBloomTextureID[i] = CreateTexture(
          e_InternalPixelFormat_RGBA16F, e_PixelFormat_RGBA,
          bloomWidth, bloomHeight, false, false, false, true, false);
      SetFrameBufferTexture2D(e_TargetAttachment_Color0,
                              view.postBloomTextureID[i]);
      SetRenderTargets({e_TargetAttachment_Color0});
      if (!CheckFrameBufferStatus())
        Log(e_FatalError, "OpenGLRenderer3D", "RenderViewPBR",
            "Could not create Bloom framebuffer");
    }
  }
  if (pbrFXAAEnabled_ && !view.postToneFrameBufferID) {
    view.postToneFrameBufferID = CreateFrameBuffer();
    BindFrameBuffer(view.postToneFrameBufferID);
    view.postToneTextureID = CreateTexture(
        e_InternalPixelFormat_RGBA8, e_PixelFormat_RGBA,
        view.width, view.height, false, false, false, true, false);
    SetFrameBufferTexture2D(e_TargetAttachment_Color0,
                            view.postToneTextureID);
    SetRenderTargets({e_TargetAttachment_Color0});
    if (!CheckFrameBufferStatus())
      Log(e_FatalError, "OpenGLRenderer3D", "RenderViewPBR",
          "Could not create tone-mapping framebuffer");
  }
  if (pbrAutoExposureEnabled_ && !view.postExposureFrameBufferID[0]) {
    for (int i = 0; i < 2; ++i) {
      view.postExposureFrameBufferID[i] = CreateFrameBuffer();
      BindFrameBuffer(view.postExposureFrameBufferID[i]);
      view.postExposureTextureID[i] = CreateTexture(
          e_InternalPixelFormat_RGBA16F, e_PixelFormat_RGBA,
          1, 1, false, false, false, false, false);
      SetFrameBufferTexture2D(e_TargetAttachment_Color0,
                              view.postExposureTextureID[i]);
      SetRenderTargets({e_TargetAttachment_Color0});
      if (!CheckFrameBufferStatus())
        Log(e_FatalError, "OpenGLRenderer3D", "RenderViewPBR",
            "Could not create exposure framebuffer");
      const GLfloat initial[4] = {1.0f, 1.0f, 1.0f, 1.0f};
      SetTextureUnit(0);
      BindTexture(view.postExposureTextureID[i]);
      mapping.glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, 1, 1,
                              GL_RGBA, GL_FLOAT, initial);
      BindTexture(0);
    }
    view.postExposureIndex = 0;
    view.postExposureInitialized = false;
  }

  SetDepthTesting(false);
  SetDepthMask(false);
  SetFramebufferGammaCorrection(false);
  if (pbrBloomEnabled_) {
    BindFrameBuffer(view.postBloomFrameBufferID[0]);
    SetRenderTargets({e_TargetAttachment_Color0});
    SetViewport(0, 0, bloomWidth, bloomHeight);
    UseShader("bloom");
    SetUniformFloat2("bloom", "outputSize", (float)bloomWidth,
                     (float)bloomHeight);
    SetTextureUnit(0);
    BindTexture(view.accumBuffer_AccumTexID);
    RenderOverlay2D();

    UseShader("blur");
    SetUniformFloat2("blur", "textureSize", (float)bloomWidth,
                     (float)bloomHeight);
    SetUniformFloat2("blur", "direction", 1.0f, 0.0f);
    BindFrameBuffer(view.postBloomFrameBufferID[1]);
    SetRenderTargets({e_TargetAttachment_Color0});
    SetTextureUnit(0);
    BindTexture(view.postBloomTextureID[0]);
    RenderOverlay2D();
    SetUniformFloat2("blur", "direction", 0.0f, 1.0f);
    BindFrameBuffer(view.postBloomFrameBufferID[0]);
    SetRenderTargets({e_TargetAttachment_Color0});
    SetTextureUnit(0);
    BindTexture(view.postBloomTextureID[1]);
    RenderOverlay2D();
    SetTextureUnit(0);
    BindTexture(0);
  }
  gpu_stage("bloom");
  // A capture toggle or repeated presentation of the same simulation state
  // must not advance eye adaptation. Actual match time is snapshot-owned.
  const unsigned long presentationTimeMs =
      pbrAutoExposureEnabled_
          ? GetGameTask()->GetMatch()->GetActualTime_ms() : 0;
  if (pbrAutoExposureEnabled_ &&
      (!view.postExposureInitialized ||
       view.postExposureTimeMs != presentationTimeMs)) {
    const int next = 1 - view.postExposureIndex;
    BindFrameBuffer(view.postExposureFrameBufferID[next]);
    SetRenderTargets({e_TargetAttachment_Color0});
    SetViewport(0, 0, 1, 1);
    UseShader("auto_exposure");
    SetTextureUnit(1);
    BindTexture(view.postExposureTextureID[view.postExposureIndex]);
    SetTextureUnit(0);
    BindTexture(view.accumBuffer_AccumTexID);
    RenderOverlay2D();
    SetTextureUnit(1);
    BindTexture(0);
    SetTextureUnit(0);
    BindTexture(0);
    view.postExposureIndex = next;
    view.postExposureTimeMs = presentationTimeMs;
    view.postExposureInitialized = true;
  }
  gpu_stage("exposure");

  int width, height, bpp;
  GetContextSize(width, height, bpp);
  const int targetY = height - (view.y + view.height);
  if (pbrFXAAEnabled_) {
    BindFrameBuffer(view.postToneFrameBufferID);
    SetRenderTargets({e_TargetAttachment_Color0});
    SetViewport(0, 0, view.width, view.height);
  } else {
    BindFrameBuffer(0);
    SetRenderTargets({e_TargetAttachment_Back});
    SetViewport(view.x, targetY, view.width, view.height);
  }

  UseShader("tonemapping");
  SetUniformFloat("tonemapping", "contextWidth", (float)view.width);
  SetUniformFloat("tonemapping", "contextHeight", (float)view.height);
  SetUniformFloat("tonemapping", "contextX",
                  pbrFXAAEnabled_ ? 0.0f : (float)view.x);
  SetUniformFloat("tonemapping", "contextY",
                  pbrFXAAEnabled_ ? 0.0f : (float)targetY);
  SetUniformFloat("tonemapping", "exposure", pbrExposure_);
  SetUniformInt("tonemapping", "useAutoExposure",
                pbrAutoExposureEnabled_ ? 1 : 0);
  SetUniformFloat("tonemapping", "bloomStrength",
                  pbrBloomEnabled_ ? 0.3f : 0.0f);

  SetTextureUnit(2);
  BindTexture(view.gBuffer_DepthTexID);
  SetTextureUnit(3);
  BindTexture(pbrAutoExposureEnabled_
                  ? view.postExposureTextureID[view.postExposureIndex] : 0);
  SetTextureUnit(1);
  BindTexture(pbrBloomEnabled_ ? view.postBloomTextureID[0] : 0);
  SetTextureUnit(0);
  BindTexture(view.accumBuffer_AccumTexID);
  RenderOverlay2D();
  gpu_stage("tone");
  SetTextureUnit(2);
  BindTexture(0);
  SetTextureUnit(3);
  BindTexture(0);
  SetTextureUnit(1);
  BindTexture(0);
  SetTextureUnit(0);
  BindTexture(0);

  if (pbrFXAAEnabled_) {
    BindFrameBuffer(0);
    SetRenderTargets({e_TargetAttachment_Back});
    SetViewport(view.x, targetY, view.width, view.height);
    UseShader("fxaa");
    SetUniformFloat2("fxaa", "textureSize",
                     (float)view.width, (float)view.height);
    SetUniformFloat2("fxaa", "contextOrigin",
                     (float)view.x, (float)targetY);
    BindTexture(view.postToneTextureID);
    RenderOverlay2D();
    SetTextureUnit(0);
    BindTexture(0);
  }
  gpu_stage("fxaa");
  SetFramebufferGammaCorrection(false);
  UseShader("");
  SetRenderTargets({e_TargetAttachment_Back});
  SetViewport(0, 0, width, height);
}
}
