
#define _GNU_SOURCE
#include <SDL2/SDL.h>
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
typedef void (*swap_fn)(SDL_Window*);
typedef void (*finish_fn)(void);
static double now_ms(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC_RAW, &ts);
  return 1000.0*(double)ts.tv_sec + (double)ts.tv_nsec/1000000.0;
}
void SDL_GL_SwapWindow(SDL_Window *window) {
  static swap_fn real_swap = NULL;
  static finish_fn real_finish = NULL;
  if (!real_swap) real_swap = (swap_fn)dlsym(RTLD_NEXT, "SDL_GL_SwapWindow");
  if (!real_finish) real_finish = (finish_fn)SDL_GL_GetProcAddress("glFinish");
  int pre = getenv("FOOTBALL_DIAG_PRE_FINISH") != NULL;
  double start=now_ms(), finished=start;
  if (pre && real_finish) { real_finish(); finished=now_ms(); }
  real_swap(window);
  double end=now_ms();
  fprintf(stderr, "SWAPDIAG pre_ms=%.6f swap_ms=%.6f interval=%d\\n",
          finished-start,end-finished,SDL_GL_GetSwapInterval());
}
