Native empty_goal training artifacts

The five models and exact Linux runtime require matching engine/data and engine/fonts from the source manifest, plus compatible host system libraries. This is not a cross-ABI or manylinux package. See LICENSE.

Set LD_LIBRARY_PATH to the extracted runtime directory, GFOOTBALL_DATA_DIR to the matching repository engine/data, and GFOOTBALL_FONT to engine/fonts/AlegreyaSansSC-ExtraBold.ttf. Use runtime/native_ppo_train --scenario empty_goal --seed SEED --hidden 16 --epochs 4 --minibatch 64 --rollout 256 --episode-limit 256 --updates 0 --no-initial-eval --load models/sparse16-SEED.bin.
